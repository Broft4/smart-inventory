const ADMIN_UI_STATE_STORAGE_KEY = 'smart_inventory_admin_ui_state';

const ADMIN_REPORT_MONTHS = [
    { value: '01', label: 'Январь' },
    { value: '02', label: 'Февраль' },
    { value: '03', label: 'Март' },
    { value: '04', label: 'Апрель' },
    { value: '05', label: 'Май' },
    { value: '06', label: 'Июнь' },
    { value: '07', label: 'Июль' },
    { value: '08', label: 'Август' },
    { value: '09', label: 'Сентябрь' },
    { value: '10', label: 'Октябрь' },
    { value: '11', label: 'Ноябрь' },
    { value: '12', label: 'Декабрь' },
];

function loadPersistedAdminUiState() {
    try {
        const raw = localStorage.getItem(ADMIN_UI_STATE_STORAGE_KEY);
        if (!raw) return { selectedLocation: '', selectedReportYear: null, selectedReportMonth: '', selectedReportId: null, selectedReportIdByLocation: {} };
        const parsed = JSON.parse(raw);
        return {
            selectedLocation: typeof parsed?.selectedLocation === 'string' ? parsed.selectedLocation : '',
            selectedReportYear: Number.isInteger(Number(parsed?.selectedReportYear)) ? Number(parsed.selectedReportYear) : null,
            selectedReportMonth: typeof parsed?.selectedReportMonth === 'string' ? parsed.selectedReportMonth : '',
            selectedReportId: null,
            selectedReportIdByLocation: {},
        };
    } catch {
        return { selectedLocation: '', selectedReportYear: null, selectedReportMonth: '', selectedReportId: null, selectedReportIdByLocation: {} };
    }
}

function persistAdminUiState() {
    try {
        localStorage.setItem(ADMIN_UI_STATE_STORAGE_KEY, JSON.stringify({
            selectedLocation: adminState.selectedLocation || '',
            selectedReportYear: adminState.selectedReportYear || null,
            selectedReportMonth: adminState.selectedReportMonth || '',
            selectedReportId: null,
            selectedReportIdByLocation: {},
        }));
    } catch {
        // ignore storage errors
    }
}

const persistedAdminUiState = loadPersistedAdminUiState();

const adminState = {
    report: null,
    selectedLocation: persistedAdminUiState.selectedLocation || '',
    selectedReportYear: persistedAdminUiState.selectedReportYear || null,
    selectedReportMonth: persistedAdminUiState.selectedReportMonth || '',
    selectedReportId: null,
    selectedReportIdByLocation: {},
    isPeriodMode: false,
    isReportViewLoading: false,
    reportViewRequestSeq: 0,
    reportsSectionRequestSeq: 0,
    reportViewAbortController: null,
    periodDateFrom: '',
    periodDateTo: '',
    employeeFilter: '',
    discrepancyOnly: false,
    expandedCategories: new Set(),
    viewMode: 'categories',
    searchQuery: '',
    diagnosticsRows: [],
    diagnosticsLocation: null,
    locations: [],
    locationModalTab: 'create',
    editingLocationId: null,
    editingDiscrepancy: null,
    editingCostOverride: null,
    cycleTargetsPreviousCategoryIds: new Set(),
    cycleTargetsPreviousSubcategoryIds: new Set(),
    cycleTargetsTargetDate: '',
    cycleTargetsMinDate: '',
    cycleTargetsMaxDate: '',
    cycleTargetsLocked: false,
    cycleTargetsLockedMessage: '',
};

function formatDateTime(value) {
    return value || '-';
}

function getTodayIsoDate() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function getDefaultReportYearMonth() {
    const today = getTodayIsoDate();
    return {
        year: Number(today.slice(0, 4)),
        month: today.slice(5, 7),
    };
}

function normalizeReportMonth(value) {
    const number = Number(value);
    if (!Number.isInteger(number) || number < 1 || number > 12) return '';
    return String(number).padStart(2, '0');
}

function getReportMonthLabel(monthValue) {
    const normalized = normalizeReportMonth(monthValue);
    return ADMIN_REPORT_MONTHS.find(item => item.value === normalized)?.label || '';
}

function getSelectedReportYearMonth() {
    const defaults = getDefaultReportYearMonth();
    const yearSelect = document.getElementById('admin-report-year-select');
    const monthSelect = document.getElementById('admin-report-month-select');
    const selectedYear = Number(yearSelect?.value || adminState.selectedReportYear || defaults.year);
    const selectedMonth = normalizeReportMonth(monthSelect?.value || adminState.selectedReportMonth || defaults.month) || defaults.month;
    adminState.selectedReportYear = selectedYear;
    adminState.selectedReportMonth = selectedMonth;
    return { year: selectedYear, month: selectedMonth };
}

function renderReportMonthSelectors() {
    const yearSelect = document.getElementById('admin-report-year-select');
    const monthSelect = document.getElementById('admin-report-month-select');
    if (!yearSelect || !monthSelect) return;

    const defaults = getDefaultReportYearMonth();
    const selectedYear = Number(adminState.selectedReportYear || defaults.year);
    const selectedMonth = normalizeReportMonth(adminState.selectedReportMonth || defaults.month) || defaults.month;
    const maxYear = Math.max(defaults.year + 1, selectedYear);
    const minYear = Math.min(2024, selectedYear, defaults.year - 5);

    yearSelect.innerHTML = Array.from({ length: maxYear - minYear + 1 }, (_, index) => maxYear - index)
        .map(year => `<option value="${year}">${year}</option>`)
        .join('');
    monthSelect.innerHTML = ADMIN_REPORT_MONTHS
        .map(month => `<option value="${month.value}">${month.label}</option>`)
        .join('');

    yearSelect.value = String(selectedYear);
    monthSelect.value = selectedMonth;
    adminState.selectedReportYear = selectedYear;
    adminState.selectedReportMonth = selectedMonth;
}

function applyDefaultPeriodInputs() {
    const fromInput = document.getElementById('admin-period-date-from');
    const toInput = document.getElementById('admin-period-date-to');
    const today = getTodayIsoDate();
    if (fromInput && !fromInput.value) fromInput.value = today;
    if (toInput && !toInput.value) toInput.value = today;
    adminState.periodDateFrom = fromInput?.value || '';
    adminState.periodDateTo = toInput?.value || '';
}

function safeText(value) {
    return value ?? '-';
}

function formatMoney(value) {
    if (value === null || value === undefined || value === '') return '—';
    const number = Number(value);
    if (!Number.isFinite(number)) return '—';
    return `${number.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₽`;
}

function formatQty(value) {
    const number = Number(value ?? 0);
    if (!Number.isFinite(number)) return '0';
    return Math.abs(number).toLocaleString('ru-RU', { minimumFractionDigits: 0, maximumFractionDigits: 3 });
}

function formatEditableQty(value) {
    const number = Number(value ?? 0);
    if (!Number.isFinite(number)) return '0';
    if (Math.abs(number - Math.round(number)) < 1e-9) {
        return String(Math.round(number));
    }
    return number.toFixed(3).replace(/\.?0+$/, '');
}

function formatFinishedAt(value) {
    if (!value) return '';
    return value;
}

function buildEmployeeRevisionStatus(employee, report) {
    if (report?.report_type === 'period') {
        return {
            label: 'Участвовал в выбранном периоде',
            className: 'orange',
            actionHtml: '',
        };
    }

    const canManage = Boolean(report?.can_manage_employee_completion && report?.report_type === 'daily');
    if (employee?.finished_current_report) {
        return {
            label: employee.finished_at ? `Завершил: ${formatFinishedAt(employee.finished_at)}` : 'Завершил ревизию',
            className: 'green',
            actionHtml: employee.can_reopen_access && canManage && employee.user_id
                ? `<button class="chip-button chip-button-warning" type="button" onclick="reopenEmployeeRevisionAccess(${Number(employee.user_id)}, '${escapeHtml(employee.full_name)}')">Вернуть в ревизию</button>`
                : '',
        };
    }

    if (employee?.started_current_report) {
        return {
            label: employee.started_at ? `В ревизии с ${formatFinishedAt(employee.started_at)}` : 'Ревизия начата',
            className: 'orange',
            actionHtml: '',
        };
    }

    return {
        label: canManage ? 'Назначена' : 'Статус только для просмотра',
        className: canManage ? 'grey' : 'orange',
        actionHtml: '',
    };
}

async function reopenEmployeeRevisionAccess(employeeUserId, employeeName) {
    const report = adminState.report;
    if (!report?.report_id || !report?.location) {
        alert('Сначала загрузите ревизию.');
        return;
    }

    if (!confirm(`Вернуть сотрудника «${employeeName}» в текущую ревизию?`)) {
        return;
    }

    setAdminReportStatus(`Возвращаем сотрудника «${employeeName}» в ревизию...`, 'loading');

    try {
        const response = await fetch(`/api/report/${report.report_id}/reopen-employee-access`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ employee_user_id: employeeUserId }),
        });
        let payload = null;
        try {
            payload = await response.json();
        } catch {
            payload = null;
        }
        if (!response.ok) {
            throw new Error(payload?.detail || payload?.message || 'Не удалось вернуть сотрудника в ревизию.');
        }

        await loadAdminReport(report.location, report.report_id);
        setAdminReportStatus(payload?.message || `Сотрудник «${employeeName}» снова может продолжить ревизию.`, 'success');
    } catch (error) {
        console.error(error);
        setAdminReportStatus(error?.message || 'Не удалось вернуть сотрудника в ревизию.', 'error');
    }
}

function renderMoneyBreakdown(unitValue, totalValue, quantity, { highlight = false, source = null, note = null } = {}) {
    const totalHtml = totalValue != null ? formatMoney(totalValue) : '—';
    const unitHtml = unitValue != null ? `${formatMoney(unitValue)}/шт` : '—';
    const qtyHtml = quantity != null ? `× ${formatQty(quantity)}` : '';
    const badgeTitle = source === 'override'
        ? escapeHtml(note ? `Локальная себестоимость: ${note}` : 'Локальная себестоимость для этой точки')
        : '';
    const badgeHtml = source === 'override'
        ? `<span class="money-badge money-badge-manual" title="${badgeTitle}">локально</span>`
        : '';
    return `
        <div class="money-cell${highlight ? ' emphasis' : ''}">
            <strong>${totalHtml}</strong>
            <span class="muted-text">${unitHtml}${qtyHtml ? ` ${qtyHtml}` : ''}</span>
            ${badgeHtml}
        </div>
    `;
}


function getEmployeeMoneyTotals(employee) {
    const discrepancyItems = Array.isArray(employee?.discrepancyItems) ? employee.discrepancyItems : [];
    const fallback = {
        total_cost: Number(employee?.total_cost || 0),
        total_retail: Number(employee?.total_retail || 0),
        total_lost_profit: Number(employee?.total_lost_profit || 0),
    };

    if (!discrepancyItems.length) {
        return fallback;
    }

    return discrepancyItems.reduce((totals, item) => ({
        total_cost: totals.total_cost + Number(item.cost_total || 0),
        total_retail: totals.total_retail + Number(item.retail_total || 0),
        total_lost_profit: totals.total_lost_profit + Number(item.lost_profit || 0),
    }), { total_cost: 0, total_retail: 0, total_lost_profit: 0 });
}

function buildSubcategoryFinancialSummaries(problemItems) {
    const groups = new Map();

    (problemItems || []).forEach(item => {
        const name = item.subcategory_name || 'Без подкатегории';
        if (!groups.has(name)) {
            groups.set(name, {
                subcategory_name: name,
                items_count: 0,
                total_cost: 0,
                total_retail: 0,
                total_lost_profit: 0,
            });
        }

        const bucket = groups.get(name);
        bucket.items_count += 1;
        bucket.total_cost += Number(item.cost_total || 0);
        bucket.total_retail += Number(item.retail_total || 0);
        bucket.total_lost_profit += Number(item.lost_profit || 0);
    });

    return [...groups.values()].sort((a, b) => a.subcategory_name.localeCompare(b.subcategory_name, 'ru'));
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

function escapeRegExp(value) {
    return String(value ?? '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function normalizeSearch(value) {
    return String(value ?? '').trim().toLowerCase();
}

function highlightMatch(text, query) {
    const safe = escapeHtml(text);
    const normalizedQuery = normalizeSearch(query);
    if (!normalizedQuery) return safe;

    const regex = new RegExp(`(${escapeRegExp(query)})`, 'ig');
    return safe.replace(regex, '<span class="search-highlight">$1</span>');
}

function encodeUser(user) {
    return encodeURIComponent(JSON.stringify(user));
}

function getUserEmail(user) {
    const value = user?.email ?? user?.recovery_email ?? user?.mail ?? '';
    return String(value || '').trim();
}


function isSuperadmin() {
    return Boolean(window.currentAdmin?.is_superadmin || window.currentAdmin?.role === 'superadmin');
}

function roleDisplayName(role) {
    if (role === 'superadmin') return 'Главный управляющий';
    if (role === 'admin') return 'Управляющий';
    if (role === 'employee') return 'Сотрудник';
    return role || '—';
}

function setMultiSelectValues(select, values) {
    if (!select) return;
    const wanted = new Set((values || []).map(value => String(value)));
    [...select.options].forEach(option => {
        option.selected = wanted.has(String(option.value));
    });
}

function getSelectedMultiSelectValues(select) {
    if (!select) return [];
    return [...select.selectedOptions].map(option => Number(option.value)).filter(Number.isFinite);
}

function updateUserFormByRole({ editingUser = null } = {}) {
    const roleSelect = document.getElementById('user-role');
    const locationRow = document.getElementById('user-location-row');
    const adminLocationsRow = document.getElementById('user-admin-locations-row');
    const locationSelect = document.getElementById('user-location');
    const adminLocationsSelect = document.getElementById('user-admin-locations');
    if (!roleSelect || !locationRow || !adminLocationsRow || !locationSelect || !adminLocationsSelect) return;

    const selectedRole = roleSelect.value;
    const editingCurrentAdmin = Boolean(editingUser && Number(editingUser.id) === Number(window.currentAdmin?.id));
    const currentIsSuperadmin = isSuperadmin();

    [...roleSelect.options].forEach(option => {
        if (option.value === 'superadmin') {
            option.hidden = !currentIsSuperadmin && !(editingUser && editingUser.role === 'superadmin');
        }
        if (option.value === 'admin') {
            option.hidden = !currentIsSuperadmin && !(editingUser && editingUser.role === 'admin');
        }
    });

    if (!currentIsSuperadmin && selectedRole !== 'employee') {
        roleSelect.value = editingCurrentAdmin ? 'admin' : 'employee';
    }

    const roleValue = roleSelect.value;
    const isEmployee = roleValue === 'employee';
    const isAdmin = roleValue === 'admin';

    locationRow.classList.toggle('hidden', !isEmployee);
    adminLocationsRow.classList.toggle('hidden', !isAdmin || !currentIsSuperadmin);

    roleSelect.disabled = !currentIsSuperadmin && editingCurrentAdmin;
    if (!isEmployee) {
        locationSelect.value = '';
    }
    if (!(isAdmin && currentIsSuperadmin)) {
        setMultiSelectValues(adminLocationsSelect, []);
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    modal.classList.remove('hidden');
    document.body.classList.add('modal-open');
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    modal.classList.add('hidden');
    if (document.querySelectorAll('.modal-overlay:not(.hidden)').length === 0) {
        document.body.classList.remove('modal-open');
    }
}

function getSelectedAdminLocation() {
    const locationSelect = document.getElementById('admin-location-select');
    return adminState.selectedLocation || locationSelect?.value || '';
}

function getCurrentAdminReportId() {
    const reportSelect = document.getElementById('admin-report-select');
    return adminState.selectedReportId || Number(reportSelect?.value || 0) || null;
}

function parseRuDateToIso(value) {
    const match = String(value || '').match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    if (!match) return '';
    const [, day, month, year] = match;
    return `${year}-${month}-${day}`;
}


function extractIsoDateFromRuDate(value) {
    const match = String(value || '').match(/^(\d{2})\.(\d{2})\.(\d{4})/);
    if (!match) return '';
    const [, day, month, year] = match;
    return `${year}-${month}-${day}`;
}

function getDefaultCycleTargetDate() {
    return getTodayIsoDate();
}

function getEmployeeSubcategoryStatsMap(report) {
    const statsMap = new Map();
    const employees = buildEmployeeDetailGroups(report);

    employees.forEach(employee => {
        const allSubcategories = new Set();
        const completedSubcategories = new Set();
        const discrepancySubcategories = new Set();

        (employee.categories || []).forEach(category => {
            (category.in_progress_subcategories || []).forEach(sub => {
                if (!sub?.name) return;
                allSubcategories.add(`${category.name}::${sub.name}`);
            });
            (category.completed_subcategories || []).forEach(sub => {
                if (!sub?.name) return;
                const key = `${category.name}::${sub.name}`;
                allSubcategories.add(key);
                completedSubcategories.add(key);
            });
        });

        (employee.discrepancyItems || []).forEach(item => {
            if (!item?.subcategory_name || item.subcategory_name === '-') return;
            const key = `${item.category_name}::${item.subcategory_name}`;
            allSubcategories.add(key);
            completedSubcategories.add(key);
            discrepancySubcategories.add(key);
        });

        statsMap.set(employee.full_name, {
            total: allSubcategories.size,
            completed: completedSubcategories.size,
            discrepancy: discrepancySubcategories.size,
        });
    });

    return statsMap;
}

function toggleReportEmployeesSection(report) {
    const section = document.getElementById('report-employees-section');
    if (!section) return;
    const employeesCount = Array.isArray(report?.employees) ? report.employees.length : 0;
    section.classList.toggle('hidden', employeesCount <= 1);
}

function setCycleTargetsSaveButtonState(isLoading) {
    const button = document.getElementById('save-cycle-targets-btn');
    if (!button) return;
    if (!button.dataset.defaultLabel) {
        button.dataset.defaultLabel = button.textContent || 'Сохранить';
    }
    button.disabled = Boolean(isLoading || adminState.cycleTargetsLocked);
    button.textContent = isLoading ? 'Сохраняем...' : button.dataset.defaultLabel;
}

function toggleCycleCategoryBody(categoryId) {
    const body = document.querySelector(`[data-cycle-category-body="${CSS.escape(categoryId)}"]`);
    const button = document.querySelector(`[data-cycle-category-toggle="${CSS.escape(categoryId)}"]`);
    if (!body || !button) return;

    const isHidden = body.classList.contains('hidden');
    if (isHidden) {
        body.classList.remove('hidden');
    } else {
        body.classList.add('hidden');
    }
    button.textContent = isHidden ? '−' : '+';
    button.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
}

function toggleCycleCompletedSubcategories(categoryId) {
    const body = document.querySelector(`[data-cycle-completed-body="${CSS.escape(categoryId)}"]`);
    const button = document.querySelector(`[data-cycle-completed-toggle="${CSS.escape(categoryId)}"]`);
    if (!body || !button) return;

    const isHidden = body.classList.contains('hidden');
    const count = Number(button.dataset.completedCount || 0);
    if (isHidden) {
        body.classList.remove('hidden');
    } else {
        body.classList.add('hidden');
    }
    button.textContent = isHidden ? 'Скрыть пройденные' : `Показать пройденные (${count})`;
    button.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
}

window.toggleCycleCategoryBody = toggleCycleCategoryBody;
window.toggleCycleCompletedSubcategories = toggleCycleCompletedSubcategories;

function updateSearchUI() {
    const input = document.getElementById('admin-search-input');
    const hint = document.getElementById('admin-search-hint');
    if (!input || !hint) return;

    if (adminState.viewMode === 'employees') {
        input.placeholder = 'Поиск по сотруднику или его категориям...';
        hint.textContent = 'В режиме «По сотрудникам» ищет по сотрудникам, их категориям и расхождениям.';
    } else {
        input.placeholder = 'Поиск по категории, подкатегории или товару...';
        hint.textContent = 'В режиме «По категориям» ищет по категориям, подкатегориям и товарам.';
    }

    input.value = adminState.searchQuery;
}

function isDiagnosticsCategoryName(name) {
    return normalizeSearch(name) === normalizeSearch('Без категории');
}

function setAdminReportStatus(message = '', type = 'loading') {
    const container = document.getElementById('admin-report-loading');
    if (!container) return;

    if (!message) {
        container.innerHTML = '';
        return;
    }

    const spinner = type === 'loading' ? '<span class="inventory-spinner" aria-hidden="true"></span>' : '';
    container.innerHTML = `
        <div class="inventory-status ${escapeHtml(type)}">
            <div class="inventory-status-row">
                ${spinner}
                <div class="inventory-status-text">${escapeHtml(message)}</div>
            </div>
        </div>
    `;
}

function updateExportReportButton(report = adminState.report) {
    const button = document.getElementById('export-report-xlsx-btn');
    if (!button) return;

    const hasExportableReport = Boolean(report && (report.report_type === 'period' || report.report_id));
    button.disabled = !hasExportableReport;
    if (!button.dataset.loading) {
        button.textContent = 'Скачать Excel';
    }
}

async function readErrorMessage(response, fallbackMessage = 'Произошла ошибка.') {
    const contentType = response.headers.get('content-type') || '';

    try {
        if (contentType.includes('application/json')) {
            const payload = await response.json();
            return payload?.detail || payload?.message || fallbackMessage;
        }

        const text = await response.text();
        return text || fallbackMessage;
    } catch (error) {
        console.error(error);
        return fallbackMessage;
    }
}

async function downloadCurrentReportExcel(triggerButton = null) {
    const report = adminState.report;
    if (!report || (!report.report_id && report.report_type !== 'period')) {
        alert('Сначала загрузите ревизию или период.');
        return;
    }

    const button = triggerButton || document.getElementById('export-report-xlsx-btn');
    const originalText = button?.textContent || 'Скачать Excel';
    if (button) {
        button.disabled = true;
        button.dataset.loading = '1';
        button.textContent = 'Готовим Excel...';
    }

    try {
        let url = '';
        if (adminState.isPeriodMode || report.report_type === 'period') {
            const location = getSelectedAdminLocation();
            const dateFrom = adminState.periodDateFrom || document.getElementById('admin-period-date-from')?.value || '';
            const dateTo = adminState.periodDateTo || document.getElementById('admin-period-date-to')?.value || '';
            if (!location || !dateFrom || !dateTo) {
                throw new Error('Для выгрузки периода выберите точку и обе даты.');
            }
            const params = new URLSearchParams({ location, date_from: dateFrom, date_to: dateTo });
            url = `/api/report-period/export-xlsx?${params.toString()}`;
        } else {
            url = `/api/report/${report.report_id}/export-xlsx`;
        }

        const response = await fetch(url);
        if (!response.ok) {
            const text = await readErrorMessage(response, 'Не удалось выгрузить Excel.');
            throw new Error(text || 'Не удалось выгрузить Excel.');
        }

        const blob = await response.blob();
        const disposition = response.headers.get('Content-Disposition') || '';
        const utfMatch = disposition.match(/filename\*=UTF-8''([^;]+)/i);
        const asciiMatch = disposition.match(/filename="?([^";]+)"?/i);
        const filename = utfMatch
            ? decodeURIComponent(utfMatch[1])
            : (asciiMatch?.[1] || `report_${report.report_id || 'period'}.xlsx`);

        const objectUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(objectUrl);
    } catch (error) {
        console.error(error);
        alert(error?.message || 'Не удалось скачать Excel.');
    } finally {
        if (button) {
            delete button.dataset.loading;
            button.textContent = originalText;
        }
        updateExportReportButton(adminState.report);
    }
}


function parseIsoDateLocal(value) {
    const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return null;
    const [, year, month, day] = match;
    const date = new Date(Number(year), Number(month) - 1, Number(day));
    return Number.isNaN(date.getTime()) ? null : date;
}

function formatIsoDateLocal(date) {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function addDaysIso(value, days) {
    const date = parseIsoDateLocal(value);
    if (!date) return '';
    date.setDate(date.getDate() + Number(days || 0));
    return formatIsoDateLocal(date);
}

function minIsoDate(...values) {
    const dates = values.map(parseIsoDateLocal).filter(Boolean);
    if (!dates.length) return '';
    return formatIsoDateLocal(new Date(Math.min(...dates.map(date => date.getTime()))));
}

function currentCycleBoundsIso(referenceIso = getTodayIsoDate()) {
    const reference = parseIsoDateLocal(referenceIso) || parseIsoDateLocal(getTodayIsoDate());
    const year = reference.getFullYear();
    const month = reference.getMonth();
    const day = reference.getDate();
    const start = new Date(year, month, day <= 15 ? 1 : 16);
    const end = day <= 15 ? new Date(year, month, 15) : new Date(year, month + 1, 0);
    return { start: formatIsoDateLocal(start), end: formatIsoDateLocal(end) };
}

function syncProblemExportDates(forcePreset = false) {
    const presetSelect = document.getElementById('problem-export-preset');
    const fromInput = document.getElementById('problem-export-date-from');
    const toInput = document.getElementById('problem-export-date-to');
    if (!presetSelect || !fromInput || !toInput) return;

    const preset = presetSelect.value || 'cycle_first_7';
    const today = getTodayIsoDate();
    const cycle = currentCycleBoundsIso(today);
    let dateFrom = fromInput.value || cycle.start;
    let dateTo = toInput.value || today;

    if (preset === 'cycle_first_7') {
        dateFrom = cycle.start;
        dateTo = minIsoDate(addDaysIso(cycle.start, 6), cycle.end);
    } else if (preset === 'cycle_to_today') {
        dateFrom = cycle.start;
        dateTo = minIsoDate(today, cycle.end);
    } else if (forcePreset && (!dateFrom || !dateTo)) {
        dateFrom = cycle.start;
        dateTo = minIsoDate(today, cycle.end);
    }

    fromInput.value = dateFrom;
    toInput.value = dateTo;
    const isCustom = preset === 'custom';
    fromInput.disabled = !isCustom;
    toInput.disabled = !isCustom;
}

function setProblemExportStatus(message = '', type = 'loading') {
    const box = document.getElementById('problem-export-status');
    if (!box) return;
    if (!message) {
        box.className = 'inventory-status hidden';
        box.textContent = '';
        return;
    }
    box.className = `inventory-status ${escapeHtml(type)}`;
    box.classList.remove('hidden');
    box.textContent = message;
}

async function downloadProblemItemsChecklistExcel(triggerButton = null) {
    const location = getSelectedAdminLocation();
    const dateFrom = document.getElementById('problem-export-date-from')?.value || '';
    const dateTo = document.getElementById('problem-export-date-to')?.value || '';
    if (!location || !dateFrom || !dateTo) {
        setProblemExportStatus('Выберите точку и период для выгрузки.', 'error');
        return;
    }
    if (dateFrom > dateTo) {
        setProblemExportStatus('Дата начала периода не может быть позже даты окончания.', 'error');
        return;
    }

    const button = triggerButton || document.getElementById('export-problem-items-xlsx-btn');
    const originalText = button?.textContent || 'Скачать проблемные товары';
    if (button) {
        button.disabled = true;
        button.textContent = 'Готовим файл...';
    }
    setProblemExportStatus('Собираем проблемные товары и актуальные остатки из МойСклад...', 'loading');

    try {
        const params = new URLSearchParams({ location, date_from: dateFrom, date_to: dateTo });
        const response = await fetch(`/api/report-problem-items/export-xlsx?${params.toString()}`);
        if (!response.ok) {
            const text = await readErrorMessage(response, 'Не удалось выгрузить проблемные товары.');
            throw new Error(text || 'Не удалось выгрузить проблемные товары.');
        }
        const blob = await response.blob();
        const disposition = response.headers.get('Content-Disposition') || '';
        const utfMatch = disposition.match(/filename\*=UTF-8''([^;]+)/i);
        const asciiMatch = disposition.match(/filename="?([^";]+)"?/i);
        const filename = utfMatch
            ? decodeURIComponent(utfMatch[1])
            : (asciiMatch?.[1] || 'problem_items_checklist.xlsx');

        const objectUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(objectUrl);
        setProblemExportStatus('Файл с проблемными товарами скачан.', 'success');
    } catch (error) {
        console.error(error);
        setProblemExportStatus(error?.message || 'Не удалось скачать файл.', 'error');
    } finally {
        if (button) {
            button.disabled = false;
            button.textContent = originalText;
        }
    }
}

function resetSummary() {
    document.getElementById('report-location').textContent = '-';
    document.getElementById('report-date').textContent = '-';
    document.getElementById('report-status').textContent = '-';
    document.getElementById('report-id').textContent = '-';
    document.getElementById('total-plus').textContent = '+0';
    document.getElementById('total-minus').textContent = '0';
    document.getElementById('report-status-chip').textContent = '—';
    document.getElementById('report-status-chip').className = 'report-status-chip';
    document.getElementById('employees-count').textContent = '0';
    document.getElementById('completed-categories').textContent = '0/0';
    document.getElementById('discrepancy-categories').textContent = '0';
    document.getElementById('no-discrepancy-categories').textContent = '0';
    document.getElementById('discrepancy-items').textContent = '0';
    document.getElementById('total-cost').textContent = '0 ₽';
    document.getElementById('total-retail').textContent = '0 ₽';
    document.getElementById('total-lost-profit').textContent = '0 ₽';
    renderSelectedCycleScope({ selected_categories: [], selected_subcategories: [] });
    updateExportReportButton(null);
}

function setAdminReportLoading(message = 'Загрузка данных ревизии...') {
    setAdminReportStatus(message, 'loading');

    const loadingCardHtml = `<div class="category-card"><p class="empty-text">${escapeHtml(message)}</p></div>`;
    const employeesContainer = document.getElementById('report-employees');
    const categoriesContainer = document.getElementById('report-categories');
    const employeeDetailsContainer = document.getElementById('report-employee-details');

    resetSummary();
    if (employeesContainer) employeesContainer.innerHTML = loadingCardHtml;
    if (categoriesContainer) categoriesContainer.innerHTML = loadingCardHtml;
    if (employeeDetailsContainer) employeeDetailsContainer.innerHTML = loadingCardHtml;
}

function updateAdminReportSelectAvailability() {
    const reportSelect = document.getElementById('admin-report-select');
    if (!reportSelect) return;

    const hasOptions = Array.from(reportSelect.options || []).some(option => option.value);
    reportSelect.disabled = adminState.isReportViewLoading || !hasOptions;
}

function beginAdminReportViewLoad() {
    if (adminState.reportViewAbortController) {
        adminState.reportViewAbortController.abort();
    }

    adminState.reportViewAbortController = new AbortController();
    adminState.reportViewRequestSeq += 1;
    adminState.isReportViewLoading = true;
    updateAdminReportSelectAvailability();

    return {
        requestSeq: adminState.reportViewRequestSeq,
        signal: adminState.reportViewAbortController.signal,
    };
}

function finishAdminReportViewLoad(requestSeq) {
    if (requestSeq !== adminState.reportViewRequestSeq) return;

    adminState.isReportViewLoading = false;
    adminState.reportViewAbortController = null;
    updateAdminReportSelectAvailability();
}

function isAbortError(error) {
    return error?.name === 'AbortError';
}

function renderDiagnostics(rows, location) {
    const summary = document.getElementById('diagnostics-summary');
    const container = document.getElementById('diagnostics-content');
    if (!summary || !container) return;

    const noCategoryCount = rows.filter(row => normalizeSearch(row.issue_type).includes('без категории')).length;
    const noSubcategoryCount = rows.filter(row => normalizeSearch(row.issue_type).includes('без подкатегории')).length;
    summary.textContent = `Точка: ${location}. Найдено записей: ${rows.length}. Без категории: ${noCategoryCount}. Без подкатегории: ${noSubcategoryCount}.`;

    if (!rows.length) {
        container.innerHTML = '<div class="category-card"><p class="empty-text">Проблемных товаров не найдено.</p></div>';
        return;
    }

    container.innerHTML = `
        <div class="table-scroll diagnostics-table-wrap">
            <table class="admin-table diagnostics-table">
                <thead>
                    <tr>
                        <th>Тип проблемы</th>
                        <th>Товар</th>
                        <th>Остаток</th>
                        <th>Куда попал</th>
                        <th>Путь папок</th>
                        <th>Источник папки</th>
                        <th>Поиск карточки</th>
                        <th>Причина</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(row => `
                        <tr>
                            <td>${escapeHtml(row.issue_type)}</td>
                            <td>
                                <strong>${escapeHtml(row.item_name)}</strong>
                                <div class="muted-text">${escapeHtml(row.item_id)}</div>
                            </td>
                            <td class="num-cell">${escapeHtml(row.expected_qty)}</td>
                            <td>
                                <div>${escapeHtml(row.category_name)}</div>
                                <div class="muted-text">${escapeHtml(row.subcategory_name)}</div>
                            </td>
                            <td>${escapeHtml(row.folder_path || '-')}</td>
                            <td>${escapeHtml(row.folder_source || '-')}</td>
                            <td>${escapeHtml(row.assortment_lookup || '-')}</td>
                            <td>${escapeHtml(row.reason || '-')}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

async function downloadDiagnosticsCsv(location, triggerButton = null) {
    const button = triggerButton || document.getElementById('diagnostics-export-btn');
    const originalText = button?.textContent || 'Скачать CSV';
    if (button) {
        button.disabled = true;
        button.textContent = 'Готовим CSV...';
    }

    try {
        const response = await fetch(`/api/inventory-diagnostics/export?location=${encodeURIComponent(location)}`);
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Не удалось выгрузить диагностику.');
        }

        const blob = await response.blob();
        const disposition = response.headers.get('Content-Disposition') || '';
        const utfMatch = disposition.match(/filename\*=UTF-8''([^;]+)/i);
        const asciiMatch = disposition.match(/filename="?([^";]+)"?/i);
        const filename = utfMatch ? decodeURIComponent(utfMatch[1]) : (asciiMatch?.[1] || `inventory_diagnostics_${location}.csv`);
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
    } catch (error) {
        console.error(error);
        alert('Не удалось скачать CSV с диагностикой.');
    } finally {
        if (button) {
            button.disabled = false;
            button.textContent = originalText;
        }
    }
}

async function openDiagnosticsModal(location, triggerButton) {
    const summary = document.getElementById('diagnostics-summary');
    const container = document.getElementById('diagnostics-content');
    if (summary) summary.textContent = '';
    if (container) container.innerHTML = '<p>Загрузка диагностики...</p>';
    showModal('diagnostics-modal');

    const originalText = triggerButton?.textContent || 'Выгрузить ошибки разметки';
    if (triggerButton) {
        triggerButton.disabled = true;
        triggerButton.textContent = 'Проверяем разметку...';
    }

    try {
        const response = await fetch(`/api/inventory-diagnostics?location=${encodeURIComponent(location)}`);
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Не удалось получить диагностику.');
        }
        const data = await response.json();
        adminState.diagnosticsRows = Array.isArray(data.rows) ? data.rows : [];
        adminState.diagnosticsLocation = location;
        renderDiagnostics(adminState.diagnosticsRows, location);
    } catch (error) {
        console.error(error);
        if (container) {
            container.innerHTML = '<div class="category-card"><p class="empty-text error-text">Не удалось загрузить диагностику разметки.</p></div>';
        }
    } finally {
        if (triggerButton) {
            triggerButton.disabled = false;
            triggerButton.textContent = originalText;
        }
    }
}



function renderLocationOptions(locations) {
    const locationSelect = document.getElementById('admin-location-select');
    const userLocation = document.getElementById('user-location');
    const adminLocations = document.getElementById('user-admin-locations');
    adminState.locations = Array.isArray(locations) ? locations : [];

    if (adminState.selectedLocation && !adminState.locations.some(location => location.name === adminState.selectedLocation)) {
        adminState.selectedLocation = adminState.locations[0]?.name || '';
        adminState.selectedReportId = null;
    }
    if (!adminState.selectedLocation && adminState.locations.length) {
        adminState.selectedLocation = adminState.locations[0].name;
        adminState.selectedReportId = null;
    }
    persistAdminUiState();

    if (locationSelect) {
        locationSelect.innerHTML = adminState.locations.length
            ? adminState.locations.map(location => `<option value="${escapeHtml(location.name)}">${escapeHtml(location.name)}</option>`).join('')
            : '<option value="">Нет доступных точек</option>';
        locationSelect.value = adminState.selectedLocation || '';
    }
    if (userLocation) {
        userLocation.innerHTML = `<option value="">— не выбрано —</option>${adminState.locations.map(location => `<option value="${escapeHtml(location.name)}">${escapeHtml(location.name)}</option>`).join('')}`;
    }
    if (adminLocations) {
        adminLocations.innerHTML = adminState.locations.map(location => `<option value="${escapeHtml(location.id)}">${escapeHtml(location.name)}</option>`).join('');
    }

    renderLocationManageList();

    if (adminState.editingLocationId && !adminState.locations.some(location => location.id === adminState.editingLocationId)) {
        adminState.editingLocationId = null;
    }
    if (!adminState.editingLocationId && adminState.locations.length) {
        selectLocationForEdit(adminState.locations[0].id);
    }
}

function getLocationById(locationId) {
    return adminState.locations.find(location => Number(location.id) === Number(locationId)) || null;
}

function setMessage(messageEl, text = '', color = '#dc3545') {
    if (!messageEl) return;
    messageEl.style.color = color;
    messageEl.textContent = text;
}

function switchLocationModalTab(tab) {
    adminState.locationModalTab = tab;
    document.querySelectorAll('[data-location-tab]').forEach(button => {
        button.classList.toggle('active', button.dataset.locationTab === tab);
    });
    document.querySelectorAll('.location-tab-panel').forEach(panel => {
        panel.classList.toggle('hidden', panel.id !== `location-tab-${tab}`);
    });

    if (tab === 'manage' && !adminState.editingLocationId && adminState.locations.length) {
        selectLocationForEdit(adminState.locations[0].id);
    }
}

function openLocationModal(tab = 'create') {
    showModal('location-modal');
    switchLocationModalTab(tab);
    renderLocationManageList();
}

function fillStoreSelect(select, stores, selectedId = '', emptyLabel = 'Выберите склад') {
    if (!select) return;
    select.innerHTML = `<option value="">${escapeHtml(emptyLabel)}</option>${(stores || []).map(store => `<option value="${escapeHtml(store.id)}" data-store-name="${escapeHtml(store.name)}" ${store.id === selectedId ? 'selected' : ''}>${escapeHtml(store.name)}</option>`).join('')}`;
}

function renderLocationManageList() {
    const container = document.getElementById('location-manage-list');
    if (!container) return;

    if (!adminState.locations.length) {
        container.innerHTML = '<div class="employee-empty-state">Точек пока нет.</div>';
        return;
    }

    container.innerHTML = adminState.locations.map(location => `
        <button type="button" class="location-manage-row ${Number(location.id) === Number(adminState.editingLocationId) ? 'active' : ''}" data-location-edit-id="${location.id}">
            <div>
                <strong>${escapeHtml(location.name)}</strong>
                <div class="muted-text">Склад: ${escapeHtml(location.ms_store_name || 'не выбран')}</div>
            </div>
            <span class="location-manage-row-arrow">→</span>
        </button>
    `).join('');
}

function selectLocationForEdit(locationId) {
    const location = getLocationById(locationId);
    const idInput = document.getElementById('location-edit-id');
    const nameInput = document.getElementById('location-edit-name');
    const tokenInput = document.getElementById('location-edit-token');
    const storeSelect = document.getElementById('location-edit-store-select');
    const message = document.getElementById('location-edit-form-message');

    if (!location || !idInput || !nameInput || !tokenInput || !storeSelect) return;

    adminState.editingLocationId = Number(location.id);
    idInput.value = String(location.id);
    nameInput.value = location.name || '';
    tokenInput.value = '';
    tokenInput.dataset.currentToken = location.ms_token || '';
    fillStoreSelect(
        storeSelect,
        location.ms_store_id ? [{ id: location.ms_store_id, name: location.ms_store_name || 'Текущий склад' }] : [],
        location.ms_store_id || '',
        location.ms_store_id ? 'Текущий склад' : 'Сначала загрузите список'
    );
    setMessage(message, '');
    renderLocationManageList();
}

async function loadStoresForSelect(token, select, message, selectedId = '') {
    if (!token) {
        setMessage(message, 'Введите токен.');
        return;
    }
    setMessage(message, '');
    if (select) select.innerHTML = '<option value="">Загрузка...</option>';

    const response = await fetch('/api/locations/stores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ms_token: token }),
    });
    const data = await response.json();
    if (!response.ok) {
        setMessage(message, data.detail || 'Не удалось получить список складов.');
        if (select) select.innerHTML = '<option value="">Ошибка загрузки</option>';
        return;
    }

    fillStoreSelect(select, data.stores || [], selectedId);
}

async function loadLocations() {
    const response = await fetch('/api/locations');
    if (!response.ok) throw new Error('Не удалось загрузить список точек');
    const data = await response.json();
    renderLocationOptions(data.locations || []);
}

async function loadStoresByToken() {
    const token = document.getElementById('location-token').value.trim();
    const message = document.getElementById('location-form-message');
    const select = document.getElementById('location-store-select');
    await loadStoresForSelect(token, select, message);
}

async function loadEditStoresByToken() {
    const location = getLocationById(adminState.editingLocationId);
    const tokenInput = document.getElementById('location-edit-token');
    const select = document.getElementById('location-edit-store-select');
    const message = document.getElementById('location-edit-form-message');
    const token = tokenInput?.value.trim() || tokenInput?.dataset?.currentToken || location?.ms_token || '';
    await loadStoresForSelect(token, select, message, location?.ms_store_id || '');
}

async function submitLocationForm(event) {
    event.preventDefault();
    const message = document.getElementById('location-form-message');
    const select = document.getElementById('location-store-select');
    const selected = select.options[select.selectedIndex];
    const payload = {
        name: document.getElementById('location-name').value.trim(),
        ms_token: document.getElementById('location-token').value.trim(),
        ms_store_id: select.value,
        ms_store_name: selected?.dataset?.storeName || selected?.textContent || '',
    };
    const response = await fetch('/api/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    });
    const data = await response.json();
    if (!response.ok) {
        setMessage(message, data.detail || data.message || 'Не удалось создать точку.');
        return;
    }
    setMessage(message, data.message || 'Точка создана.', '#1f9d55');
    document.getElementById('location-form')?.reset();
    document.getElementById('location-store-select').innerHTML = '<option value="">Сначала загрузите список</option>';
    await loadLocations();
    adminState.selectedLocation = data.location?.name || adminState.selectedLocation;
    const adminLocationSelect = document.getElementById('admin-location-select');
    if (adminLocationSelect) adminLocationSelect.value = adminState.selectedLocation;
    if (data.location?.id) {
        selectLocationForEdit(data.location.id);
        switchLocationModalTab('manage');
    }
    await reloadReportsSection(adminState.selectedLocation);
}

async function submitLocationEditForm(event) {
    event.preventDefault();
    const location = getLocationById(adminState.editingLocationId);
    const message = document.getElementById('location-edit-form-message');
    const select = document.getElementById('location-edit-store-select');
    if (!location) {
        setMessage(message, 'Сначала выберите точку слева.');
        return;
    }

    const tokenInput = document.getElementById('location-edit-token');
    const selected = select.options[select.selectedIndex];
    const resolvedToken = tokenInput?.value.trim() || tokenInput?.dataset?.currentToken || location.ms_token || '';
    const payload = {
        name: document.getElementById('location-edit-name').value.trim(),
        ms_token: resolvedToken,
        ms_store_id: select.value || location.ms_store_id || '',
        ms_store_name: selected?.dataset?.storeName || selected?.textContent || location.ms_store_name || '',
    };

    const response = await fetch(`/api/locations/${location.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    });
    const data = await response.json();
    if (!response.ok) {
        setMessage(message, data.detail || data.message || 'Не удалось обновить точку.');
        return;
    }

    const oldName = location.name;
    setMessage(message, data.message || 'Точка обновлена.', '#1f9d55');
    await loadLocations();
    adminState.editingLocationId = data.location?.id || location.id;
    selectLocationForEdit(adminState.editingLocationId);

    if (adminState.selectedLocation === oldName) {
        adminState.selectedLocation = data.location?.name || adminState.selectedLocation;
        const adminLocationSelect = document.getElementById('admin-location-select');
        if (adminLocationSelect) adminLocationSelect.value = adminState.selectedLocation;
        await reloadReportsSection(adminState.selectedLocation);
    }
}

async function deleteSelectedLocation() {
    const location = getLocationById(adminState.editingLocationId);
    const message = document.getElementById('location-edit-form-message');
    if (!location) {
        setMessage(message, 'Сначала выберите точку слева.');
        return;
    }
    if (!confirm(`Удалить точку «${location.name}»?`)) return;

    const response = await fetch(`/api/locations/${location.id}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok) {
        setMessage(message, data.detail || data.message || 'Не удалось удалить точку.');
        return;
    }

    const deletedName = location.name;
    setMessage(message, data.message || 'Точка удалена.', '#1f9d55');
    await loadLocations();

    if (adminState.selectedLocation === deletedName) {
        adminState.selectedLocation = adminState.locations[0]?.name || '';
        const adminLocationSelect = document.getElementById('admin-location-select');
        if (adminLocationSelect) adminLocationSelect.value = adminState.selectedLocation || '';
        if (adminState.selectedLocation) {
            await reloadReportsSection(adminState.selectedLocation);
        }
    }
}

function renderUsers(users) {
    const container = document.getElementById('users-list');
    if (!users.length) {
        container.innerHTML = '<p>Пользователей пока нет.</p>';
        return;
    }

    container.innerHTML = users.map(user => {
        const locationInfo = user.role === 'admin'
            ? (Array.isArray(user.admin_locations) && user.admin_locations.length ? `точки: ${escapeHtml(user.admin_locations.join(', '))}` : 'точки не назначены')
            : escapeHtml(user.location || 'без точки');
        const email = getUserEmail(user);
        const emailText = email ? escapeHtml(email) : '<span class="muted-text-warning">не указана</span>';
        return `
            <div class="user-row">
                <div>
                    <strong>${escapeHtml(user.full_name)}</strong>
                    <div class="muted-text">${escapeHtml(user.username)} · ${escapeHtml(roleDisplayName(user.role))} · ${locationInfo}</div>
                    <div class="muted-text">Дата рождения: ${escapeHtml(user.birth_date)} · ${user.is_active ? 'активен' : 'выключен'}</div>
                    <div class="muted-text">Почта для восстановления: ${emailText}</div>
                </div>
                <div class="user-row-actions">
                    <button class="btn secondary btn-inline" data-user="${encodeUser(user)}" onclick="editUserFromEncoded(this.dataset.user)">Редактировать</button>
                    <button class="btn danger btn-inline" onclick="deleteUser(${user.id})">Удалить</button>
                </div>
            </div>
        `;
    }).join('');
}

window.editUserFromEncoded = function (encodedUser) {
    const user = JSON.parse(decodeURIComponent(encodedUser));
    document.getElementById('user-form-title').textContent = 'Редактировать пользователя';
    document.getElementById('user-id').value = user.id;
    document.getElementById('user-full-name').value = user.full_name;
    document.getElementById('user-birth-date').value = user.birth_date;
    document.getElementById('user-username').value = user.username;
    document.getElementById('user-email').value = getUserEmail(user);
    document.getElementById('user-password').value = '';
    document.getElementById('user-role').value = user.role;
    document.getElementById('user-location').value = user.location || '';
    setMultiSelectValues(document.getElementById('user-admin-locations'), user.admin_location_ids || []);
    document.getElementById('user-active').checked = Boolean(user.is_active);
    document.getElementById('user-form-message').textContent = '';
    document.getElementById('user-form-message').style.color = '#dc3545';
    updateUserFormByRole({ editingUser: user });
    showModal('users-modal');
    showModal('user-form-modal');
};

function resetUserForm() {
    document.getElementById('user-form-title').textContent = 'Создать пользователя';
    document.getElementById('user-id').value = '';
    document.getElementById('user-form').reset();
    document.getElementById('user-email').value = '';
    document.getElementById('user-active').checked = true;
    document.getElementById('user-form-message').textContent = '';
    document.getElementById('user-form-message').style.color = '#dc3545';
    document.getElementById('user-location').value = '';
    setMultiSelectValues(document.getElementById('user-admin-locations'), []);
    if (!isSuperadmin()) {
        document.getElementById('user-role').value = 'employee';
    }
    updateUserFormByRole();
}

function openCreateUserModal() {
    resetUserForm();
    updateUserFormByRole();
    showModal('users-modal');
    showModal('user-form-modal');
}

async function loadUsers() {
    const response = await fetch('/api/users');
    if (!response.ok) throw new Error('Ошибка загрузки пользователей');
    const data = await response.json();
    renderUsers(data.users);
}

async function extractErrorMessage(response) {
    try {
        const data = await response.json();
        if (Array.isArray(data.detail)) {
            return data.detail.map(item => item.msg).join(', ');
        }
        if (typeof data.detail === 'string') return data.detail;
        if (typeof data.message === 'string') return data.message;
        return 'Не удалось сохранить пользователя.';
    } catch {
        return 'Не удалось сохранить пользователя.';
    }
}

async function submitUserForm(event) {
    event.preventDefault();
    const userId = document.getElementById('user-id').value;
    const message = document.getElementById('user-form-message');
    message.textContent = '';
    message.style.color = '#dc3545';

    const password = document.getElementById('user-password').value;
    const selectedRole = document.getElementById('user-role').value;
    const payload = {
        full_name: document.getElementById('user-full-name').value.trim(),
        birth_date: document.getElementById('user-birth-date').value,
        username: document.getElementById('user-username').value.trim(),
        email: document.getElementById('user-email').value.trim() || null,
        role: selectedRole,
        location: selectedRole === 'employee' ? (document.getElementById('user-location').value || null) : null,
        admin_location_ids: selectedRole === 'admin' ? getSelectedMultiSelectValues(document.getElementById('user-admin-locations')) : [],
        is_active: document.getElementById('user-active').checked,
    };

    if (userId) {
        if (password.trim()) payload.password = password;
    } else {
        payload.password = password;
    }

    const url = userId ? `/api/users/${userId}` : '/api/users';
    const method = userId ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        if (!response.ok) {
            message.textContent = await extractErrorMessage(response);
            return;
        }

        const data = await response.json();
        message.style.color = '#1f9d55';
        message.textContent = data.message || 'Пользователь сохранён.';
        await loadUsers();

        setTimeout(() => {
            hideModal('user-form-modal');
            resetUserForm();
        }, 500);
    } catch (error) {
        console.error(error);
        message.textContent = 'Ошибка сохранения пользователя.';
    }
}

window.deleteUser = async function (userId) {
    if (!confirm('Удалить сотрудника?')) return;
    const response = await fetch(`/api/users/${userId}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok) {
        alert(data.detail || data.message || 'Не удалось удалить пользователя.');
        return;
    }
    await loadUsers();
};


function updateCycleTargetDependencyState() {
    document.querySelectorAll('[data-cycle-category-id]').forEach(categoryCheckbox => {
        const categoryId = categoryCheckbox.dataset.cycleCategoryId;
        const subCheckboxes = document.querySelectorAll(`[data-cycle-subcategory-for="${CSS.escape(categoryId)}"]`);
        const categorySelected = Boolean(categoryCheckbox.checked);

        subCheckboxes.forEach(subCheckbox => {
            const wasChecked = subCheckbox.checked;
            const baseDisabled = subCheckbox.dataset.baseDisabled === 'true';
            subCheckbox.disabled = adminState.cycleTargetsLocked || baseDisabled || categorySelected;
            if (categorySelected && wasChecked && !adminState.cycleTargetsLocked) {
                subCheckbox.checked = false;
            }
        });
    });

    renderCycleTargetsSelectionSummary();
}

function renderCycleTargetsSelectionSummary() {
    const selectedCountNode = document.getElementById('cycle-targets-selected-count');
    const filteredCountNode = document.getElementById('cycle-targets-filtered-count');
    const categoryCheckboxes = [...document.querySelectorAll('[data-cycle-category-id]')];
    const subcategoryCheckboxes = [...document.querySelectorAll('[data-cycle-subcategory-id]')];
    const completedSubcategoryNodes = [...document.querySelectorAll('[data-cycle-completed-subcategory-id]')];

    if (selectedCountNode) {
        const selectedCategoryCount = categoryCheckboxes.filter(node => node.checked).length;
        const selectedSubcategoryCount = subcategoryCheckboxes.filter(node => node.checked).length;
        selectedCountNode.textContent = adminState.cycleTargetsLocked
            ? `Выбрано на дату: категорий ${selectedCategoryCount}. Подкатегорий ${selectedSubcategoryCount}.`
            : `Новый выбор: категорий ${selectedCategoryCount}. Подкатегорий ${selectedSubcategoryCount}.`;
    }

    if (filteredCountNode) {
        const availableSubcategories = subcategoryCheckboxes.filter(node => !node.disabled || node.checked).length;
        filteredCountNode.textContent = `Показано категорий: ${categoryCheckboxes.length}. Видно подкатегорий: ${availableSubcategories}. Уже пройдено до выбранной даты: ${completedSubcategoryNodes.length}.`;
    }
}

function clearCycleTargetsSelection() {
    document.querySelectorAll('[data-cycle-category-id], [data-cycle-subcategory-id]').forEach(checkbox => {
        checkbox.checked = false;
        checkbox.disabled = false;
    });
    updateCycleTargetDependencyState();
}

function rememberCycleTargetsPreviousSelection(data) {
    adminState.cycleTargetsPreviousCategoryIds = new Set(
        (Array.isArray(data?.previous_category_ids) ? data.previous_category_ids : []).map(id => String(id)),
    );
    adminState.cycleTargetsPreviousSubcategoryIds = new Set(
        (Array.isArray(data?.previous_subcategory_ids) ? data.previous_subcategory_ids : []).map(id => String(id)),
    );
}

function applyPreviousCycleTargetsSelection() {
    const message = document.getElementById('cycle-targets-message');
    const categoryIds = adminState.cycleTargetsPreviousCategoryIds || new Set();
    const subcategoryIds = adminState.cycleTargetsPreviousSubcategoryIds || new Set();

    if (adminState.cycleTargetsLocked) {
        setMessage(message, adminState.cycleTargetsLockedMessage || 'Для завершённой ревизии выбор менять нельзя.', '#b06000');
        return;
    }

    if (!categoryIds.size && !subcategoryIds.size) {
        setMessage(message, 'Прошлого доступного выбора для этой даты нет.', '#6b7280');
        return;
    }

    let appliedCategories = 0;
    let appliedSubcategories = 0;

    document.querySelectorAll('[data-cycle-category-id]').forEach(checkbox => {
        const shouldCheck = categoryIds.has(String(checkbox.dataset.cycleCategoryId || ''));
        if (shouldCheck && !checkbox.checked) {
            checkbox.checked = true;
            appliedCategories += 1;
        }
    });

    document.querySelectorAll('[data-cycle-subcategory-id]').forEach(checkbox => {
        const shouldCheck = subcategoryIds.has(String(checkbox.dataset.cycleSubcategoryId || ''));
        if (!shouldCheck) return;
        const parentCategoryId = String(checkbox.dataset.cycleSubcategoryFor || '');
        const parentCheckbox = document.querySelector(`[data-cycle-category-id="${CSS.escape(parentCategoryId)}"]`);
        if (parentCheckbox?.checked) return;
        if (!checkbox.checked) {
            checkbox.checked = true;
            appliedSubcategories += 1;
        }
    });

    updateCycleTargetDependencyState();
    setMessage(
        message,
        `Добавлен прошлый выбор: категорий ${appliedCategories}, подкатегорий ${appliedSubcategories}. Можно отметить новые и сохранить.`,
        '#1f9d55',
    );
}

function updateSelectedScopeHeader(report) {
    const title = document.getElementById('selected-scope-title');
    const subtitle = document.getElementById('selected-scope-subtitle');
    if (!title || !subtitle) return;

    if (report?.report_type === 'period') {
        title.textContent = 'Что было в выбранном периоде';
        subtitle.textContent = 'Категории и подкатегории, которые попадали в ревизии выбранного периода.';
        return;
    }

    if (report?.report_type === 'final') {
        title.textContent = 'Что было в этом цикле';
        subtitle.textContent = 'Сводный список категорий и подкатегорий, которые попадали в ревизии выбранного цикла.';
        return;
    }

    title.textContent = 'Выбрано в текущей ревизии';
    subtitle.textContent = 'Категории и подкатегории текущей ревизии с подсветкой того, что уже взято или завершено.';
}

function updateReportActionButtons(report) {
    const deleteButton = document.getElementById('delete-report-btn');
    const resetPeriodButton = document.getElementById('reset-period-report-btn');
    if (deleteButton) {
        deleteButton.disabled = Boolean(adminState.isPeriodMode || !adminState.selectedReportId);
    }
    if (resetPeriodButton) {
        resetPeriodButton.disabled = !adminState.isPeriodMode;
    }
}

function renderSelectedCycleScope(report) {
    const categoriesContainer = document.getElementById('selected-cycle-categories-list');
    const subcategoriesContainer = document.getElementById('selected-cycle-subcategories-list');
    if (!categoriesContainer || !subcategoriesContainer) return;

    if (report?.report_type !== 'daily') {
        const selectedCategories = Array.isArray(report?.selected_categories) ? report.selected_categories : [];
        const selectedSubcategories = Array.isArray(report?.selected_subcategories) ? report.selected_subcategories : [];
        categoriesContainer.innerHTML = selectedCategories.length
            ? selectedCategories.map(name => `<span class="category-chip">${highlightMatch(name, adminState.searchQuery)}</span>`).join('')
            : '<span class="muted-text">Нет выбранных категорий</span>';
        subcategoriesContainer.innerHTML = selectedSubcategories.length
            ? selectedSubcategories.map(name => `<span class="category-chip">${highlightMatch(name, adminState.searchQuery)}</span>`).join('')
            : '<span class="muted-text">Нет выбранных подкатегорий</span>';
        return;
    }

    const categoryChips = [];
    const subcategoryChips = [];
    const seenCategoryLabels = new Set();
    const seenSubcategoryLabels = new Set();
    const categories = Array.isArray(report?.categories) ? report.categories : [];

    const pushCategoryChip = (label, variant = '') => {
        const key = normalizeSearch(label);
        if (!key || seenCategoryLabels.has(key)) return;
        seenCategoryLabels.add(key);
        const extraClass = variant ? ` ${variant}` : '';
        categoryChips.push(`<span class="category-chip${extraClass}">${highlightMatch(label, adminState.searchQuery)}</span>`);
    };

    const pushSubcategoryChip = (label, variant = '', owner = '') => {
        const key = normalizeSearch(`${label}::${owner}`);
        if (!key || seenSubcategoryLabels.has(key)) return;
        seenSubcategoryLabels.add(key);
        const extraClass = variant ? ` ${variant}` : '';
        subcategoryChips.push(`<span class="category-chip${extraClass}">${highlightMatch(label, adminState.searchQuery)}${owner ? ` · ${highlightMatch(owner, adminState.searchQuery)}` : ''}</span>`);
    };

    categories.forEach(category => {
        const categoryLabel = category?.name || '';
        const completedSubNames = new Set((Array.isArray(category?.completed_subcategories) ? category.completed_subcategories : [])
            .map(sub => normalizeSearch(sub?.name || ''))
            .filter(Boolean));
        const discrepancySubNames = new Set((Array.isArray(category?.problem_items) ? category.problem_items : [])
            .map(item => normalizeSearch(item?.subcategory_name || ''))
            .filter(Boolean));
        const inProgressSubcategories = Array.isArray(category?.in_progress_subcategories) ? category.in_progress_subcategories : [];
        const selectedSubNames = Array.isArray(category?.selected_subcategories) ? category.selected_subcategories : [];

        if (category?.selected_on_cycle) {
            if (['green', 'red'].includes(normalizeSearch(category.status || ''))) {
                pushCategoryChip(categoryLabel, 'category-chip--success');
            } else if (inProgressSubcategories.length || category?.assigned_to) {
                pushCategoryChip(categoryLabel, 'category-chip--warning');
            } else {
                pushCategoryChip(categoryLabel);
            }
        }

        selectedSubNames.forEach(subName => {
            const label = categoryLabel ? `${categoryLabel} → ${subName}` : subName;
            const normalizedSubName = normalizeSearch(subName);
            if (completedSubNames.has(normalizedSubName) || discrepancySubNames.has(normalizedSubName)) {
                pushSubcategoryChip(label, 'category-chip--success');
            } else {
                const inProgress = inProgressSubcategories.find(sub => normalizeSearch(sub?.name || '') === normalizedSubName);
                if (inProgress) {
                    pushSubcategoryChip(label, 'category-chip--warning', inProgress.assigned_to || '');
                } else {
                    pushSubcategoryChip(label);
                }
            }
        });

        inProgressSubcategories.forEach(sub => {
            const subName = sub?.name || '';
            if (!subName) return;
            const normalizedSubName = normalizeSearch(subName);
            if (completedSubNames.has(normalizedSubName) || discrepancySubNames.has(normalizedSubName)) return;
            const label = categoryLabel ? `${categoryLabel} → ${subName}` : subName;
            pushSubcategoryChip(label, 'category-chip--warning', sub?.assigned_to || '');
        });

        (Array.isArray(category?.completed_subcategories) ? category.completed_subcategories : []).forEach(sub => {
            const subName = sub?.name || '';
            if (!subName) return;
            const label = categoryLabel ? `${categoryLabel} → ${subName}` : subName;
            pushSubcategoryChip(label, 'category-chip--success', sub?.checked_by || '');
        });

        (Array.isArray(category?.problem_items) ? category.problem_items : []).forEach(item => {
            const subName = item?.subcategory_name || '';
            if (!subName || subName === '-') return;
            const label = categoryLabel ? `${categoryLabel} → ${subName}` : subName;
            pushSubcategoryChip(label, 'category-chip--success', item?.checked_by || '');
        });
    });

    categoriesContainer.innerHTML = categoryChips.length
        ? categoryChips.join('')
        : '<span class="muted-text">Нет выбранных категорий</span>';
    subcategoriesContainer.innerHTML = subcategoryChips.length
        ? subcategoryChips.join('')
        : '<span class="muted-text">Нет выбранных подкатегорий</span>';
}

function renderCycleTargets(data) {
    const container = document.getElementById('cycle-targets-list');
    const meta = document.getElementById('cycle-targets-meta');
    const cycleStartInput = document.getElementById('cycle-start-date');
    const targetDateInput = document.getElementById('cycle-target-date');
    const applyPreviousButton = document.getElementById('apply-previous-cycle-targets-btn');
    if (!container) return;

    const categories = Array.isArray(data?.categories) ? data.categories : [];
    rememberCycleTargetsPreviousSelection(data);
    adminState.cycleTargetsTargetDate = data?.target_date || '';
    adminState.cycleTargetsMinDate = data?.min_target_date || '';
    adminState.cycleTargetsMaxDate = data?.max_target_date || '';
    adminState.cycleTargetsLocked = Boolean(data?.is_locked);
    adminState.cycleTargetsLockedMessage = data?.locked_message || '';

    if (meta) {
        const previousLabel = data?.previous_target_date
            ? ` · прошлый сохранённый выбор: ${data.previous_target_date}`
            : '';
        const cycleRangeLabel = data?.min_target_date && data?.max_target_date
            ? ` · цикл: ${data.min_target_date} — ${data.max_target_date}`
            : '';
        const lockLabel = data?.is_locked
            ? ` · ${data?.report_status || 'Только просмотр'}`
            : '';
        meta.textContent = `Точка: ${data?.location || '-'} · Версия цикла: ${data?.cycle_version || '-'} · Старт цикла: ${data?.cycle_started_at || '-'} · Дата ревизии: ${data?.target_date || '-'}${cycleRangeLabel}${previousLabel}${lockLabel}`;
    }
    if (cycleStartInput) {
        cycleStartInput.value = parseRuDateToIso(data?.cycle_started_at || '');
        cycleStartInput.disabled = true;
        cycleStartInput.readOnly = true;
    }
    if (targetDateInput) {
        targetDateInput.value = data?.target_date || '';
        targetDateInput.min = data?.min_target_date || '';
        targetDateInput.max = data?.max_target_date || '';
    }
    setCycleTargetsSaveButtonState(false);
    const modalMessage = document.getElementById('cycle-targets-message');
    if (data?.is_locked) {
        setMessage(modalMessage, data?.locked_message || 'Для завершённой ревизии выбор менять нельзя.', '#b06000');
    } else {
        setMessage(modalMessage, '');
    }
    if (applyPreviousButton) {
        const hasPrevious = Boolean(adminState.cycleTargetsPreviousCategoryIds?.size || adminState.cycleTargetsPreviousSubcategoryIds?.size);
        applyPreviousButton.disabled = Boolean(data?.is_locked || !hasPrevious);
    }

    if (!categories.length) {
        container.innerHTML = '<div class="category-card"><p class="empty-text">Нет доступных категорий для настройки ревизии на выбранную дату.</p></div>';
        renderCycleTargetsSelectionSummary();
        return;
    }

    container.innerHTML = categories.map(category => {
        const subcategories = Array.isArray(category.subcategories) ? category.subcategories : [];
        const completedSubcategories = Array.isArray(category.completed_subcategories) ? category.completed_subcategories : [];
        const hasSubcategories = subcategories.length > 0;
        const hasCompletedSubcategories = completedSubcategories.length > 0;
        const expanded = category.selected || subcategories.some(sub => sub.selected);
        return `
            <article class="category-card admin-category-card status-grey">
                <div class="admin-category-header">
                    <label class="checkbox-row" style="display:flex;align-items:flex-start;gap:10px;flex:1;cursor:${(category.disabled || adminState.cycleTargetsLocked) ? 'not-allowed' : 'pointer'};opacity:${(category.disabled || adminState.cycleTargetsLocked) ? '0.68' : '1'};">
                        <input
                            type="checkbox"
                            data-cycle-category-id="${escapeHtml(category.id)}"
                            data-base-disabled="${category.disabled ? 'true' : 'false'}"
                            ${category.selected ? 'checked' : ''}
                            ${(category.disabled || adminState.cycleTargetsLocked) ? 'disabled' : ''}
                        >
                        <div>
                            <strong>${escapeHtml(category.name)}</strong>
                            <div class="muted-text">
                                ${(category.disabled || adminState.cycleTargetsLocked) && !category.selected
                                    ? 'Всю категорию на эту дату выбрать нельзя: часть подкатегорий уже занята в других ревизиях цикла или дата закрыта.'
                                    : 'Выбрать всю категорию на выбранную дату. Сотрудники увидят только подкатегории, актуальные для этой даты.'}
                            </div>
                        </div>
                    </label>
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">
                        ${hasCompletedSubcategories ? `
                            <button
                                type="button"
                                class="chip-button"
                                data-cycle-completed-toggle="${escapeHtml(category.id)}"
                                data-completed-count="${completedSubcategories.length}"
                                aria-expanded="false"
                                onclick="toggleCycleCompletedSubcategories('${escapeHtml(category.id)}')"
                            >Показать пройденные (${completedSubcategories.length})</button>
                        ` : ''}
                        ${hasSubcategories ? `
                            <button
                                type="button"
                                class="chip-button"
                                data-cycle-category-toggle="${escapeHtml(category.id)}"
                                aria-expanded="${expanded ? 'true' : 'false'}"
                                onclick="toggleCycleCategoryBody('${escapeHtml(category.id)}')"
                            >${expanded ? '−' : '+'}</button>
                        ` : ''}
                    </div>
                </div>
                ${hasSubcategories ? `
                    <div class="admin-category-body ${expanded ? '' : 'hidden'}" data-cycle-category-body="${escapeHtml(category.id)}">
                        <div style="display:grid;gap:8px;">
                            ${subcategories.map(subcategory => `
                                <label class="checkbox-row" style="display:flex;align-items:flex-start;gap:10px;cursor:${(subcategory.disabled || adminState.cycleTargetsLocked) ? 'not-allowed' : 'pointer'};opacity:${(subcategory.disabled || adminState.cycleTargetsLocked) ? '0.68' : '1'};">
                                    <input
                                        type="checkbox"
                                        data-cycle-subcategory-id="${escapeHtml(subcategory.id)}"
                                        data-cycle-subcategory-for="${escapeHtml(category.id)}"
                                        data-base-disabled="${subcategory.disabled ? 'true' : 'false'}"
                                        ${subcategory.selected ? 'checked' : ''}
                                        ${(subcategory.disabled || category.selected || adminState.cycleTargetsLocked) ? 'disabled' : ''}
                                    >
                                    <div>
                                        <strong>${escapeHtml(subcategory.name)}</strong>
                                        <div class="muted-text">Выбрать отдельно только эту подкатегорию на выбранную дату</div>
                                    </div>
                                </label>
                            `).join('')}
                        </div>
                    </div>
                ` : `
                    <div class="admin-category-body" data-cycle-category-body="${escapeHtml(category.id)}">
                        <div class="muted-text">Для этой даты свободных подкатегорий в категории не осталось.</div>
                    </div>
                `}
                ${hasCompletedSubcategories ? `
                    <div class="admin-category-body hidden" data-cycle-completed-body="${escapeHtml(category.id)}" style="margin-top:12px;border-top:1px solid rgba(148,163,184,0.25);padding-top:12px;">
                        <div class="success-text" style="margin-bottom:8px;font-weight:600;">Успешно пройденные до выбранной даты</div>
                        <div class="employee-category-chips">
                            ${completedSubcategories.map(subcategory => `<span class="category-chip" data-cycle-completed-subcategory-id="${escapeHtml(subcategory.id)}">${escapeHtml(subcategory.name)}</span>`).join('')}
                        </div>
                    </div>
                ` : ''}
            </article>
        `;
    }).join('');

    updateCycleTargetDependencyState();

    container.querySelectorAll('[data-cycle-category-id], [data-cycle-subcategory-id]').forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateCycleTargetDependencyState();
        });
    });
}

async function openCycleTargetsModal(targetDate = getDefaultCycleTargetDate()) {
    const location = getSelectedAdminLocation();
    const container = document.getElementById('cycle-targets-list');
    const message = document.getElementById('cycle-targets-message');
    const meta = document.getElementById('cycle-targets-meta');
    const targetDateInput = document.getElementById('cycle-target-date');

    if (!location) {
        alert('Сначала выберите точку.');
        return;
    }

    if (container) container.innerHTML = '<p>Загрузка...</p>';
    if (meta) meta.textContent = '';
    if (targetDateInput && targetDate) targetDateInput.value = targetDate;
    setMessage(message, '');
    adminState.cycleTargetsLocked = false;
    adminState.cycleTargetsLockedMessage = '';
    setCycleTargetsSaveButtonState(false);
    showModal('cycle-targets-modal');

    try {
        const params = new URLSearchParams({ location });
        if (targetDate) {
            params.set('target_date', targetDate);
        }
        const response = await fetch(`/api/cycle-targets?${params.toString()}`);
        let data = null;
        try {
            data = await response.json();
        } catch {
            data = null;
        }

        if (!response.ok) {
            throw new Error(data?.detail || data?.message || 'Не удалось загрузить категории цикла.');
        }

        renderCycleTargets(data);
    } catch (error) {
        if (container) container.innerHTML = '<p class="empty-text">Не удалось загрузить категории цикла.</p>';
        if (meta) meta.textContent = '';
        setMessage(message, error?.message || 'Не удалось загрузить категории цикла.', '#b00020');
    }
}

async function saveCycleTargetsSelection() {
    const location = getSelectedAdminLocation();
    const message = document.getElementById('cycle-targets-message');
    const cycleStartInput = document.getElementById('cycle-start-date');
    const targetDateInput = document.getElementById('cycle-target-date');

    if (!location) {
        setMessage(message, 'Сначала выберите точку.');
        return;
    }
    if (adminState.cycleTargetsLocked) {
        setMessage(message, adminState.cycleTargetsLockedMessage || 'Для завершённой ревизии выбор менять нельзя.', '#b06000');
        return;
    }

    const categoryIds = [...document.querySelectorAll('[data-cycle-category-id]:checked')].map(node => node.dataset.cycleCategoryId).filter(Boolean);
    const subcategoryIds = [...document.querySelectorAll('[data-cycle-subcategory-id]:checked')].map(node => node.dataset.cycleSubcategoryId).filter(Boolean);
    const hasPreviousSelection = Boolean(adminState.cycleTargetsPreviousCategoryIds?.size || adminState.cycleTargetsPreviousSubcategoryIds?.size);
    const targetDate = targetDateInput?.value || adminState.cycleTargetsTargetDate || getDefaultCycleTargetDate();

    if (!categoryIds.length && !subcategoryIds.length && hasPreviousSelection) {
        setMessage(message, 'Пустой выбор не сохраняется. Оставлен предыдущий выбор для выбранной даты.', '#6b7280');
        await openCycleTargetsModal(targetDate);
        return;
    }

    setCycleTargetsSaveButtonState(true);
    setMessage(message, 'Сохраняем...', '#6b7280');

    try {
        const response = await fetch('/api/cycle-targets', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                location,
                cycle_started_at: null,
                target_date: targetDate || null,
                category_ids: categoryIds,
                subcategory_ids: subcategoryIds,
            }),
        });

        let data = null;
        try {
            data = await response.json();
        } catch {
            data = null;
        }

        if (!response.ok) {
            setMessage(message, data?.detail || data?.message || 'Не удалось сохранить категории цикла.');
            return;
        }

        setMessage(message, data?.message || 'Изменения сохранены.', '#1f9d55');
        await openCycleTargetsModal(data?.target_date || targetDate);
        await reloadReportsSection(location);
    } finally {
        setCycleTargetsSaveButtonState(false);
    }
}

function getCategoryStatusLabel(status, category = null) {
    const name = typeof category === 'string' ? category : (category?.name || '');
    if (isDiagnosticsCategoryName(name)) return 'Не входит в ревизию';
    if (status === 'green') return 'Завершена';
    if (status === 'orange') return 'В работе';
    if (status === 'red') return 'Есть расхождения';
    return 'Назначена';
}

function getCategoryStatusClass(status, category = null) {
    const name = typeof category === 'string' ? category : (category?.name || '');
    if (isDiagnosticsCategoryName(name)) return 'status-chip grey';
    if (status === 'green') return 'status-chip green';
    if (status === 'orange') return 'status-chip orange';
    if (status === 'red') return 'status-chip red';
    return 'status-chip grey';
}

function setViewMode(mode) {
    adminState.viewMode = mode === 'employees' ? 'employees' : 'categories';

    const categoriesBlock = document.getElementById('report-categories');
    const employeesBlock = document.getElementById('report-employee-details');
    const buttons = document.querySelectorAll('[data-view-mode]');

    buttons.forEach(button => {
        button.classList.toggle('active', button.dataset.viewMode === adminState.viewMode);
    });

    if (categoriesBlock && employeesBlock) {
        categoriesBlock.classList.toggle('hidden', adminState.viewMode !== 'categories');
        employeesBlock.classList.toggle('hidden', adminState.viewMode !== 'employees');
    }

    updateSearchUI();

    if (adminState.report) {
        renderAllReportViews(adminState.report);
    }
}

function getFilteredCategories(report) {
    let categories = [...(report.categories || [])];

    if (adminState.employeeFilter) {
        categories = categories.filter(cat => cat.assigned_to === adminState.employeeFilter);
    }

    if (adminState.discrepancyOnly) {
        categories = categories.filter(cat => (cat.problem_items || []).length > 0);
    }

    return categories;
}

function filterCategoriesBySearch(categories) {
    if (adminState.viewMode !== 'categories') return categories;

    const q = normalizeSearch(adminState.searchQuery);
    if (!q) return categories;

    return categories
        .map(category => {
            const categoryName = normalizeSearch(category.name);
            const assignedName = normalizeSearch(category.assigned_to || '');

            const categorySubcategories = Array.isArray(category.selected_subcategories) ? category.selected_subcategories : [];
            const completedSubcategories = Array.isArray(category.completed_subcategories) ? category.completed_subcategories : [];
            const inProgressSubcategories = Array.isArray(category.in_progress_subcategories) ? category.in_progress_subcategories : [];
            const subcategoryMatched = categorySubcategories.some(subName =>
                normalizeSearch(subName).includes(q)
            ) || completedSubcategories.some(sub =>
                normalizeSearch(sub.name).includes(q) || normalizeSearch(sub.checked_by || '').includes(q)
            ) || inProgressSubcategories.some(sub =>
                normalizeSearch(sub.name).includes(q) || normalizeSearch(sub.assigned_to || '').includes(q)
            );

            const matchedProblemItems = (category.problem_items || []).filter(item => {
                const itemName = normalizeSearch(item.name);
                const checkedBy = normalizeSearch(item.checked_by || '');
                const subcategoryName = normalizeSearch(item.subcategory_name || '');
                return (
                    itemName.includes(q) ||
                    checkedBy.includes(q) ||
                    subcategoryName.includes(q)
                );
            });

            const matched =
                categoryName.includes(q) ||
                assignedName.includes(q) ||
                subcategoryMatched ||
                matchedProblemItems.length > 0;

            if (!matched) return null;

            const categoryMatchedDirectly =
                categoryName.includes(q) || assignedName.includes(q) || subcategoryMatched;

            return {
                ...category,
                problem_items: categoryMatchedDirectly
                    ? (category.problem_items || [])
                    : matchedProblemItems,
            };
        })
        .filter(Boolean);
}

function buildEmployeeDetailGroups(report) {
    const employeeMap = new Map();
    const categories = getFilteredCategories(report);
    const knownEmployeeNames = new Set((report.employees || []).map(employee => employee.full_name));

    const ensureEmployeeBucket = (name, base = {}) => {
        if (!employeeMap.has(name)) {
            employeeMap.set(name, {
                user_id: base.user_id || null,
                full_name: name,
                categories: [],
                discrepancyItems: [],
                completed: base.completed || 0,
                discrepancyCount: base.discrepancyCount || 0,
                total_cost: Number(base.total_cost || 0),
                total_retail: Number(base.total_retail || 0),
                total_lost_profit: Number(base.total_lost_profit || 0),
                started_current_report: Boolean(base.started_current_report),
                started_at: base.started_at || null,
                finished_current_report: Boolean(base.finished_current_report),
                finished_at: base.finished_at || null,
                can_reopen_access: Boolean(base.can_reopen_access),
            });
        }
        return employeeMap.get(name);
    };

    (report.employees || []).forEach(employee => {
        ensureEmployeeBucket(employee.full_name, {
            user_id: employee.user_id || null,
            completed: employee.completed_categories || 0,
            discrepancyCount: employee.discrepancy_items || 0,
            total_cost: Number(employee.total_cost || 0),
            total_retail: Number(employee.total_retail || 0),
            total_lost_profit: Number(employee.total_lost_profit || 0),
            started_current_report: Boolean(employee.started_current_report),
            started_at: employee.started_at || null,
            finished_current_report: Boolean(employee.finished_current_report),
            finished_at: employee.finished_at || null,
            can_reopen_access: Boolean(employee.can_reopen_access),
        });
    });

    categories.forEach(category => {
        const categoryOwner = category.assigned_to || 'Без закрепления';
        const completedSubcategories = Array.isArray(category.completed_subcategories) ? category.completed_subcategories : [];
        const inProgressSubcategories = Array.isArray(category.in_progress_subcategories) ? category.in_progress_subcategories : [];
        const problemItems = Array.isArray(category.problem_items) ? category.problem_items : [];
        const ownerNames = new Set();

        if (category.assigned_to && knownEmployeeNames.has(category.assigned_to)) {
            ownerNames.add(category.assigned_to);
        }

        completedSubcategories.forEach(sub => {
            if (sub?.checked_by && knownEmployeeNames.has(sub.checked_by)) {
                ownerNames.add(sub.checked_by);
            }
        });

        inProgressSubcategories.forEach(sub => {
            if (sub?.assigned_to && knownEmployeeNames.has(sub.assigned_to)) {
                ownerNames.add(sub.assigned_to);
            }
        });

        problemItems.forEach(item => {
            if (item?.checked_by && knownEmployeeNames.has(item.checked_by)) {
                ownerNames.add(item.checked_by);
            }
        });

        if (!ownerNames.size) {
            ownerNames.add(categoryOwner);
        }

        ownerNames.forEach(owner => {
            const bucket = ensureEmployeeBucket(owner);
            const employeeCompletedSubcategories = completedSubcategories.filter(sub => {
                if (!sub?.checked_by) return owner === 'Без закрепления';
                return sub.checked_by === owner;
            });
            const employeeInProgressSubcategories = inProgressSubcategories.filter(sub => {
                if (!sub?.assigned_to) return owner === 'Без закрепления';
                return sub.assigned_to === owner;
            });
            const employeeProblemItems = problemItems.filter(item => {
                const responsibleEmployee = item.checked_by || categoryOwner || 'Без закрепления';
                return responsibleEmployee === owner;
            });

            const shouldIncludeCategory =
                category.assigned_to === owner ||
                employeeCompletedSubcategories.length > 0 ||
                employeeInProgressSubcategories.length > 0 ||
                employeeProblemItems.length > 0;

            if (!shouldIncludeCategory) {
                return;
            }

            bucket.categories.push({
                name: category.name,
                status: category.status,
                problemCount: employeeProblemItems.length,
                in_progress_subcategories: employeeInProgressSubcategories,
                completed_subcategories: employeeCompletedSubcategories,
            });
        });

        problemItems.forEach(item => {
            const responsibleEmployee = item.checked_by || categoryOwner || 'Без закрепления';
            const bucket = ensureEmployeeBucket(responsibleEmployee);
            bucket.discrepancyItems.push({
                check_result_id: item.check_result_id || null,
                category_name: category.name,
                subcategory_name: item.subcategory_name || '-',
                name: item.name,
                expected: item.expected,
                actual: item.actual,
                diff: item.diff,
                checked_by: item.checked_by || responsibleEmployee,
                cost_price: item.cost_price,
                retail_price: item.retail_price,
                cost_total: item.cost_total,
                retail_total: item.retail_total,
                lost_profit: item.lost_profit,
                cost_price_source: item.cost_price_source || null,
                cost_price_note: item.cost_price_note || null,
                cost_price_updated_at: item.cost_price_updated_at || null,
            });
        });
    });

    return [...employeeMap.values()]
        .filter(employee => employee.categories.length || employee.discrepancyItems.length || employee.started_current_report || employee.finished_current_report)
        .sort((a, b) => a.full_name.localeCompare(b.full_name, 'ru'));
}

function filterEmployeeGroupsBySearch(employees) {
    if (adminState.viewMode !== 'employees') return employees;

    const q = normalizeSearch(adminState.searchQuery);
    if (!q) return employees;

    return employees
        .map(employee => {
            const employeeName = normalizeSearch(employee.full_name);

            const matchedCategories = (employee.categories || []).filter(category =>
                normalizeSearch(category.name).includes(q) ||
                (category.completed_subcategories || []).some(sub =>
                    normalizeSearch(sub.name).includes(q) || normalizeSearch(sub.checked_by || '').includes(q)
                ) ||
                (category.in_progress_subcategories || []).some(sub =>
                    normalizeSearch(sub.name).includes(q) || normalizeSearch(sub.assigned_to || '').includes(q)
                )
            );

            const matchedDiscrepancies = (employee.discrepancyItems || []).filter(item => {
                return (
                    normalizeSearch(item.category_name).includes(q) ||
                    normalizeSearch(item.subcategory_name || '').includes(q) ||
                    normalizeSearch(item.name).includes(q) ||
                    normalizeSearch(item.checked_by).includes(q)
                );
            });

            const matched =
                employeeName.includes(q) ||
                matchedCategories.length > 0 ||
                matchedDiscrepancies.length > 0;

            if (!matched) return null;

            const employeeMatchedDirectly = employeeName.includes(q);

            return {
                ...employee,
                categories: employeeMatchedDirectly ? (employee.categories || []) : matchedCategories,
                discrepancyItems: employeeMatchedDirectly ? (employee.discrepancyItems || []) : matchedDiscrepancies,
            };
        })
        .filter(Boolean);
}

function getFilteredEmployeeSummaries(report) {
    let employees = [...(report.employees || [])];

    if (adminState.employeeFilter) {
        employees = employees.filter(employee => employee.full_name === adminState.employeeFilter);
    }

    if (adminState.discrepancyOnly) {
        employees = employees.filter(employee => (employee.discrepancy_items || 0) > 0);
    }

    if (adminState.viewMode === 'employees') {
        const q = normalizeSearch(adminState.searchQuery);
        if (q) {
            employees = employees.filter(employee => {
                const employeeName = normalizeSearch(employee.full_name);
                const categoriesText = normalizeSearch((employee.categories || []).join(' '));
                return employeeName.includes(q) || categoriesText.includes(q);
            });
        }
    }

    return employees;
}

function renderEmployeeDetails(report) {
    const container = document.getElementById('report-employee-details');
    if (!container) return;

    let employees = buildEmployeeDetailGroups(report);
    employees = filterEmployeeGroupsBySearch(employees);

    if (!employees.length) {
        container.innerHTML = '<div class="category-card"><p class="empty-text">По текущим фильтрам сотрудники не найдены.</p></div>';
        return;
    }

    container.innerHTML = employees.map(employee => {
        const moneyTotals = getEmployeeMoneyTotals(employee);
        const categoriesHtml = employee.categories.length
            ? `<div class="employee-detail-category-list">${employee.categories.map(category => {
                const inProgressSubcategories = Array.isArray(category.in_progress_subcategories) ? category.in_progress_subcategories : [];
                const completedSubcategories = Array.isArray(category.completed_subcategories) ? category.completed_subcategories : [];
                const inProgressSubcategoriesHtml = inProgressSubcategories.length
                    ? `
                        <div class="category-card" style="margin-top:10px;padding:12px 14px;box-shadow:none;border:1px solid rgba(148,163,184,.24);">
                            <div class="muted-text" style="margin-bottom:8px;">Взято сотрудником в этой ревизии</div>
                            <div class="employee-category-chips">${inProgressSubcategories.map(sub => `<span class="category-chip category-chip--warning">${highlightMatch(sub.name, adminState.searchQuery)}</span>`).join('')}</div>
                        </div>
                    `
                    : '';
                const completedSubcategoriesHtml = completedSubcategories.length
                    ? `
                        <div class="category-card category-card--success" style="margin-top:10px;padding:12px 14px;box-shadow:none;">
                            <div class="success-text" style="margin-bottom:8px;font-weight:600;">Успешно пройденные в этой ревизии</div>
                            <div class="employee-category-chips">${completedSubcategories.map(sub => `<span class="category-chip category-chip--success">${highlightMatch(sub.name, adminState.searchQuery)}</span>`).join('')}</div>
                        </div>
                    `
                    : '';
                const emptyStateHtml = !inProgressSubcategories.length && !completedSubcategories.length
                    ? '<div class="muted-text" style="margin-top:10px;">По этой категории у сотрудника пока нет взятых или успешно завершённых подкатегорий.</div>'
                    : '';
                return `
                <div class="employee-detail-category-row">
                    <div>
                        <strong>${highlightMatch(category.name, adminState.searchQuery)}</strong>
                        <div class="muted-text">${category.problemCount ? `Проблемных товаров: ${category.problemCount}` : 'Без расхождений'}</div>
                        ${inProgressSubcategoriesHtml}
                        ${completedSubcategoriesHtml}
                        ${emptyStateHtml}
                    </div>
                    <span class="${getCategoryStatusClass(category.status, category)}">${getCategoryStatusLabel(category.status, category)}</span>
                </div>
            `;
            }).join('')}</div>`
            : '<p class="empty-text">Категории по текущим фильтрам не найдены.</p>';

        const discrepanciesHtml = employee.discrepancyItems.length
            ? `
                <div class="table-scroll">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Категория</th>
                                <th>Подкатегория</th>
                                <th>Товар</th>
                                <th>План</th>
                                <th>Факт</th>
                                <th>Разница</th>
                                <th>Себестоимость</th>
                                <th>Розница</th>
                                <th>Утерянная прибыль</th>
                                <th>Сотрудник</th>
                                <th class="actions-col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            ${employee.discrepancyItems.map(item => {
                                const diffSign = item.diff > 0 ? '+' : '';
                                const diffClass = item.diff > 0 ? 'diff-plus' : 'diff-minus';
                                const canEditDiscrepancy = item.check_result_id && report?.report_type === 'daily';
                                const canEditCostOverride = Boolean(item.check_result_id);
                                return `
                                    <tr>
                                        <td>${highlightMatch(item.category_name, adminState.searchQuery)}</td>
                                        <td>${highlightMatch(item.subcategory_name || '-', adminState.searchQuery)}</td>
                                        <td>${highlightMatch(item.name, adminState.searchQuery)}</td>
                                        <td class="num-cell">${item.expected}</td>
                                        <td class="num-cell">${item.actual}</td>
                                        <td class="num-cell ${diffClass}">${diffSign}${item.diff}</td>
                                        <td class="num-cell">${renderMoneyBreakdown(item.cost_price, item.cost_total, item.diff, { source: item.cost_price_source, note: item.cost_price_note })}</td>
                                        <td class="num-cell">${renderMoneyBreakdown(item.retail_price, item.retail_total, item.diff)}</td>
                                        <td class="num-cell">${renderMoneyBreakdown((item.retail_price !== null && item.retail_price !== undefined && item.cost_price !== null && item.cost_price !== undefined) ? Number(item.retail_price) - Number(item.cost_price) : null, item.lost_profit, item.diff, { highlight: true })}</td>
                                        <td><span class="employee-pill">${highlightMatch(item.checked_by, adminState.searchQuery)}</span></td>
                                        <td class="actions-cell">
                                            ${canEditDiscrepancy ? `
                                                <button
                                                    type="button"
                                                    class="icon-action-btn"
                                                    data-edit-discrepancy
                                                    data-check-result-id="${item.check_result_id}"
                                                    data-category-name="${escapeHtml(item.category_name)}"
                                                    data-subcategory-name="${escapeHtml(item.subcategory_name || '')}"
                                                    data-item-name="${escapeHtml(item.name)}"
                                                    data-expected="${item.expected}"
                                                    data-actual="${item.actual}"
                                                    aria-label="Изменить факт по товару ${escapeHtml(item.name)}"
                                                    title="Изменить факт"
                                                >✏️</button>
                                            ` : ''}
                                            ${canEditCostOverride ? `
                                                <button
                                                    type="button"
                                                    class="icon-action-btn"
                                                    data-edit-cost-override
                                                    data-check-result-id="${item.check_result_id}"
                                                    data-category-name="${escapeHtml(item.category_name)}"
                                                    data-subcategory-name="${escapeHtml(item.subcategory_name || '')}"
                                                    data-item-name="${escapeHtml(item.name)}"
                                                    data-cost-price="${item.cost_price ?? ''}"
                                                    data-cost-note="${escapeHtml(item.cost_price_note || '')}"
                                                    data-cost-source="${escapeHtml(item.cost_price_source || '')}"
                                                    aria-label="Задать локальную себестоимость для ${escapeHtml(item.name)}"
                                                    title="Локальная себестоимость"
                                                >₽</button>
                                            ` : ''}
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `
            : '<div class="category-empty-state green">У этого сотрудника нет расхождений по текущим фильтрам.</div>';

        const revisionStatus = buildEmployeeRevisionStatus(employee, report);
        const employeeSubcategoryKeys = new Set();
        (employee.categories || []).forEach(category => {
            (category.in_progress_subcategories || []).forEach(sub => {
                if (sub?.name) employeeSubcategoryKeys.add(`${category.name}::${sub.name}`);
            });
            (category.completed_subcategories || []).forEach(sub => {
                if (sub?.name) employeeSubcategoryKeys.add(`${category.name}::${sub.name}`);
            });
        });
        (employee.discrepancyItems || []).forEach(item => {
            if (item?.subcategory_name && item.subcategory_name !== '-') {
                employeeSubcategoryKeys.add(`${item.category_name}::${item.subcategory_name}`);
            }
        });
        return `
            <article class="category-card employee-detail-card">
                <div class="employee-detail-header">
                    <div>
                        <h3>${highlightMatch(employee.full_name, adminState.searchQuery)}</h3>
                        <p class="muted-text">Категории сотрудника и проблемные позиции в одном месте.</p>
                        ${(employee.user_id || employee.finished_current_report) ? `
                        <div class="employee-revision-row" style="margin-top:8px;">
                            <span class="status-chip ${revisionStatus.className}">${escapeHtml(revisionStatus.label)}</span>
                            ${revisionStatus.actionHtml}
                        </div>
                        ` : ''}
                    </div>
                    <div class="employee-detail-kpis">
                        <div><span class="summary-label">Подкатегорий</span><strong>${employeeSubcategoryKeys.size}</strong></div>
                        <div><span class="summary-label">Расхождений</span><strong>${employee.discrepancyItems.length}</strong></div>
                    </div>
                </div>
                <div class="employee-detail-economics">
                    <div class="employee-detail-economics-card">
                        <span class="summary-label">Себестоимость</span>
                        <strong>${formatMoney(moneyTotals.total_cost)}</strong>
                    </div>
                    <div class="employee-detail-economics-card">
                        <span class="summary-label">Розница</span>
                        <strong>${formatMoney(moneyTotals.total_retail)}</strong>
                    </div>
                    <div class="employee-detail-economics-card accent">
                        <span class="summary-label">Утерянная прибыль</span>
                        <strong>${formatMoney(moneyTotals.total_lost_profit)}</strong>
                    </div>
                </div>
                <div class="employee-detail-section">
                    <h4>Категории</h4>
                    ${categoriesHtml}
                </div>
                <div class="employee-detail-section">
                    <h4>Расхождения</h4>
                    ${discrepanciesHtml}
                </div>
            </article>
        `;
    }).join('');
}

function populateEmployeeFilter(report) {
    const select = document.getElementById('admin-employee-filter');
    const current = adminState.employeeFilter;
    const options = ['<option value="">Все сотрудники</option>'];

    (report.employees || []).forEach(employee => {
        options.push(`<option value="${escapeHtml(employee.full_name)}">${escapeHtml(employee.full_name)}</option>`);
    });

    select.innerHTML = options.join('');
    select.value = current;
}

function updateSummary(report) {
    document.getElementById('report-location').textContent = report.location;
    document.getElementById('report-date').textContent = formatDateTime(report.date);
    const typeSuffix = report.report_type === 'final'
        ? ' · итоговая'
        : (report.report_type === 'period' ? ' · период' : '');
    document.getElementById('report-status').textContent = `${report.status || '-'}${typeSuffix}`;
    document.getElementById('report-id').textContent = report.report_type === 'final'
        ? 'Итоговая'
        : (report.report_type === 'period' ? 'Период' : (report.report_number ?? report.report_id ?? '-'));
    document.getElementById('total-plus').textContent = `+${report.total_plus}`;
    document.getElementById('total-minus').textContent = report.total_minus;
    document.getElementById('report-status-chip').textContent = report.status || '-';
    document.getElementById('report-status-chip').className = `report-status-chip ${((report.status || '').toLowerCase().includes('заверш')) ? 'completed' : 'progress'}`;

    const countedCategories = (report.categories || []).filter(cat => !isDiagnosticsCategoryName(cat.name));
    const discrepancyItems = countedCategories.reduce((sum, cat) => sum + (cat.problem_items || []).length, 0);

    document.getElementById('employees-count').textContent = String((report.employees || []).length);
    document.getElementById('completed-categories').textContent = `${Number(report.completed_subcategories_count || 0)}/${Number(report.total_subcategories || 0)}`;
    document.getElementById('discrepancy-categories').textContent = String(Number(report.discrepancy_subcategories_count || 0));
    document.getElementById('no-discrepancy-categories').textContent = String(Number(report.no_discrepancy_subcategories_count || 0));
    document.getElementById('discrepancy-items').textContent = String(discrepancyItems);
    document.getElementById('total-cost').textContent = formatMoney(report.total_cost);
    document.getElementById('total-retail').textContent = formatMoney(report.total_retail);
    document.getElementById('total-lost-profit').textContent = formatMoney(report.total_lost_profit);
    updateSelectedScopeHeader(report);
    renderSelectedCycleScope(report);
    updateReportActionButtons(report);
    updateExportReportButton(report);
    toggleReportEmployeesSection(report);
}

function renderEmployees(report) {
    const container = document.getElementById('report-employees');
    const employees = getFilteredEmployeeSummaries(report);
    const subcategoryStatsMap = getEmployeeSubcategoryStatsMap(report);

    if (!employees.length) {
        container.innerHTML = '<p class="empty-text">По текущим фильтрам сотрудники не найдены.</p>';
        return;
    }

    container.innerHTML = `
        <div class="employee-summary-grid">
            ${employees.map(employee => {
                const revisionStatus = buildEmployeeRevisionStatus(employee, report);
                const subcategoryStats = subcategoryStatsMap.get(employee.full_name) || { total: 0, completed: 0, discrepancy: Number(employee.discrepancy_items || 0) };
                return `
                <article class="employee-summary-card">
                    <div class="employee-card-head">
                        <h3>${highlightMatch(employee.full_name, adminState.viewMode === 'employees' ? adminState.searchQuery : '')}</h3>
                        <div class="employee-card-actions">
                            ${revisionStatus.actionHtml}
                            <button class="chip-button" type="button" onclick="filterByEmployee('${escapeHtml(employee.full_name)}')">Показать</button>
                        </div>
                    </div>
                    <div class="employee-revision-row">
                        <span class="status-chip ${revisionStatus.className}">${escapeHtml(revisionStatus.label)}</span>
                    </div>
                    <div class="employee-meta-grid">
                        <div>
                            <span class="summary-label">Подкатегории</span>
                            <strong>${subcategoryStats.total}</strong>
                        </div>
                        <div>
                            <span class="summary-label">Завершено</span>
                            <strong>${subcategoryStats.completed}</strong>
                        </div>
                        <div>
                            <span class="summary-label">Расхождений</span>
                            <strong>${subcategoryStats.discrepancy}</strong>
                        </div>
                        <div>
                            <span class="summary-label">Себестоимость</span>
                            <strong>${formatMoney(employee.total_cost)}</strong>
                        </div>
                        <div>
                            <span class="summary-label">Розница</span>
                            <strong>${formatMoney(employee.total_retail)}</strong>
                        </div>
                        <div>
                            <span class="summary-label">Утерянная прибыль</span>
                            <strong>${formatMoney(employee.total_lost_profit)}</strong>
                        </div>
                    </div>
                    <div class="employee-category-chips">
                        ${employee.categories.length
                            ? employee.categories.map(category => `<span class="category-chip">${highlightMatch(category, adminState.viewMode === 'employees' ? adminState.searchQuery : '')}</span>`).join('')
                            : '<span class="muted-text">Категории ещё не закреплены</span>'}
                    </div>
                </article>
            `; }).join('')}
        </div>
    `;
}


function getCategoryAssignedBadge(cat) {
    if (!cat?.assigned_to) return 'Категория пока не закреплена';
    if (cat.assignment_scope === 'partial') {
        return `Подкатегории закреплены за: ${highlightMatch(cat.assigned_to, adminState.searchQuery)}`;
    }
    if (cat.assignment_scope === 'mixed') {
        return 'Подкатегории закреплены за несколькими сотрудниками';
    }
    return `Закреплена за: ${highlightMatch(cat.assigned_to, adminState.searchQuery)}`;
}

function renderCategories(report) {
    const categoriesContainer = document.getElementById('report-categories');
    let categories = getFilteredCategories(report);
    categories = filterCategoriesBySearch(categories);

    if (!categories.length) {
        categoriesContainer.innerHTML = '<div class="category-card"><p class="empty-text">По текущим фильтрам ничего не найдено.</p></div>';
        return;
    }

    categoriesContainer.innerHTML = categories.map((cat) => {
        const key = `${report.report_id || 'none'}:${cat.name}`;
        const isDiagnostic = isDiagnosticsCategoryName(cat.name);
        const isOpen = adminState.expandedCategories.has(key);
        const problemItems = cat.problem_items || [];
        const selectedSubcategories = Array.isArray(cat.selected_subcategories) ? cat.selected_subcategories : [];
        const inProgressSubcategories = Array.isArray(cat.in_progress_subcategories) ? cat.in_progress_subcategories : [];
        const remainingSubcategories = Array.isArray(cat.remaining_subcategories) ? cat.remaining_subcategories : [];
        const completedSubcategories = Array.isArray(cat.completed_subcategories) ? cat.completed_subcategories : [];
        const selectionText = report?.report_type === 'period'
            ? (cat.selected_on_cycle
                ? 'В периоде брали всю категорию'
                : (selectedSubcategories.length ? `В периоде затрагивалось подкатегорий: ${selectedSubcategories.length}` : ''))
            : (cat.selected_on_cycle
                ? 'На цикл выбрана вся категория'
                : (selectedSubcategories.length ? `На цикл выбрано подкатегорий: ${selectedSubcategories.length}` : ''));
        const summaryText = isDiagnostic
            ? 'Служебная ветка. Не входит в общую ревизию.'
            : (problemItems.length
                ? `Проблемных товаров: ${problemItems.length}`
                : (cat.status === 'green' ? 'Без расхождений' : getCategoryStatusLabel(cat.status, cat)));
        const subcategoryFinancialSummaries = buildSubcategoryFinancialSummaries(problemItems);
        const statusClass = getCategoryStatusClass(cat.status, cat);
        const statusLabel = getCategoryStatusLabel(cat.status, cat);
        const articleStatusClass = isDiagnostic ? 'status-grey' : `status-${cat.status}`;

        return `
            <article class="category-card admin-category-card ${articleStatusClass}">
                <button class="admin-category-header" type="button" onclick="toggleAdminCategory('${escapeHtml(key)}')">
                    <div>
                        <h3>${highlightMatch(cat.name, adminState.searchQuery)}</h3>
                        <div class="admin-category-subline">
                            <span class="assigned-badge">${getCategoryAssignedBadge(cat)}</span>
                            <span class="muted-text">${selectionText ? `${selectionText} · ${summaryText}` : summaryText}</span>
                        </div>
                    </div>
                    <div class="admin-category-header-right">
                        <span class="${statusClass}">${statusLabel}</span>
                        <span class="collapse-icon">${isOpen ? '−' : '+'}</span>
                    </div>
                </button>
                <div class="admin-category-body ${isOpen ? '' : 'hidden'}">
                    ${(!isDiagnostic && (cat.selected_on_cycle || selectedSubcategories.length || inProgressSubcategories.length || completedSubcategories.length || remainingSubcategories.length)) ? `
                        <div class="category-card" style="margin-bottom:12px;padding:14px 16px;box-shadow:none;border:1px solid rgba(148,163,184,.24);">
                            <div class="muted-text" style="margin-bottom:8px;">Взято сотрудниками в этой ревизии</div>
                            ${inProgressSubcategories.length
                                ? `<div class="employee-category-chips">${inProgressSubcategories.map(sub => `<span class="category-chip category-chip--warning">${highlightMatch(sub.name, adminState.searchQuery)}${sub.assigned_to ? ` · ${highlightMatch(sub.assigned_to, adminState.searchQuery)}` : ''}</span>`).join('')}</div>`
                                : '<div class="muted-text">В этой ревизии по этой категории ещё нет незавершённых взятых подкатегорий.</div>'}
                        </div>
                    ` : ''}
                    ${completedSubcategories.length ? `
                        <div class="category-card category-card--success" style="margin-bottom:12px;padding:14px 16px;box-shadow:none;">
                            <div class="success-text" style="margin-bottom:8px;font-weight:600;">Успешно пройденные подкатегории в этой ревизии</div>
                            <div class="employee-category-chips">
                                ${completedSubcategories.map(sub => `<span class="category-chip category-chip--success">${highlightMatch(sub.name, adminState.searchQuery)}${sub.checked_by ? ` · ${highlightMatch(sub.checked_by, adminState.searchQuery)}` : ''}</span>`).join('')}
                            </div>
                        </div>
                    ` : ''}
                    ${problemItems.length ? `
                        ${isDiagnostic ? '' : '<div class="discrepancy-banner">⚠️ Зафиксированы расхождения</div>'}
                        ${subcategoryFinancialSummaries.length ? `
                            <div class="admin-category-economics">
                                ${subcategoryFinancialSummaries.map(summary => `
                                    <div class="admin-category-economics-card">
                                        <span class="summary-label">${highlightMatch(summary.subcategory_name, adminState.searchQuery)} · товаров: ${summary.items_count}</span>
                                        <strong>Себестоимость: ${formatMoney(summary.total_cost)}</strong>
                                        <div class="muted-text">Розница: ${formatMoney(summary.total_retail)}</div>
                                        <div class="muted-text">Утерянная прибыль: ${formatMoney(summary.total_lost_profit)}</div>
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}
                        <div class="table-scroll">
                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>Подкатегория</th>
                                        <th>Товар</th>
                                        <th>План</th>
                                        <th>Факт</th>
                                        <th>Разница</th>
                                        <th>Себестоимость</th>
                                        <th>Розница</th>
                                        <th>Утерянная прибыль</th>
                                        <th>Сотрудник</th>
                                        <th class="actions-col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${problemItems.map(item => {
                                        const diffSign = item.diff > 0 ? '+' : '';
                                        const diffClass = item.diff > 0 ? 'diff-plus' : 'diff-minus';
                                        const canEditDiscrepancy = item.check_result_id && report?.report_type === 'daily';
                                        const canEditCostOverride = Boolean(item.check_result_id);
                                        return `
                                            <tr>
                                                <td>${highlightMatch(item.subcategory_name || '-', adminState.searchQuery)}</td>
                                                <td>${highlightMatch(item.name, adminState.searchQuery)}</td>
                                                <td class="num-cell">${item.expected}</td>
                                                <td class="num-cell">${item.actual}</td>
                                                <td class="num-cell ${diffClass}">${diffSign}${item.diff}</td>
                                                <td class="num-cell">${renderMoneyBreakdown(item.cost_price, item.cost_total, item.diff, { source: item.cost_price_source, note: item.cost_price_note })}</td>
                                                <td class="num-cell">${renderMoneyBreakdown(item.retail_price, item.retail_total, item.diff)}</td>
                                                <td class="num-cell">${renderMoneyBreakdown((item.retail_price !== null && item.retail_price !== undefined && item.cost_price !== null && item.cost_price !== undefined) ? Number(item.retail_price) - Number(item.cost_price) : null, item.lost_profit, item.diff, { highlight: true })}</td>
                                                <td><span class="employee-pill">${highlightMatch(item.checked_by || '-', adminState.searchQuery)}</span></td>
                                                <td class="actions-cell">
                                                    ${canEditDiscrepancy ? `
                                                        <button
                                                            type="button"
                                                            class="icon-action-btn"
                                                            data-edit-discrepancy
                                                            data-check-result-id="${item.check_result_id}"
                                                            data-category-name="${escapeHtml(cat.name)}"
                                                            data-subcategory-name="${escapeHtml(item.subcategory_name || '')}"
                                                            data-item-name="${escapeHtml(item.name)}"
                                                            data-expected="${item.expected}"
                                                            data-actual="${item.actual}"
                                                            aria-label="Изменить факт по товару ${escapeHtml(item.name)}"
                                                            title="Изменить факт"
                                                        >✏️</button>
                                                    ` : ''}
                                                    ${canEditCostOverride ? `
                                                        <button
                                                            type="button"
                                                            class="icon-action-btn"
                                                            data-edit-cost-override
                                                            data-check-result-id="${item.check_result_id}"
                                                            data-category-name="${escapeHtml(cat.name)}"
                                                            data-subcategory-name="${escapeHtml(item.subcategory_name || '')}"
                                                            data-item-name="${escapeHtml(item.name)}"
                                                            data-cost-price="${item.cost_price ?? ''}"
                                                            data-cost-note="${escapeHtml(item.cost_price_note || '')}"
                                                            data-cost-source="${escapeHtml(item.cost_price_source || '')}"
                                                            aria-label="Задать локальную себестоимость для ${escapeHtml(item.name)}"
                                                            title="Локальная себестоимость"
                                                        >₽</button>
                                                    ` : ''}
                                                </td>
                                            </tr>
                                        `;
                                    }).join('')}
                                </tbody>
                            </table>
                        </div>
                    ` : `
                        <div class="category-empty-state ${isDiagnostic ? 'grey' : cat.status}">
                            ${isDiagnostic
                                ? 'Эта служебная категория не включается в общую ревизию.'
                                : cat.status === 'green'
                                    ? 'Категория завершена без расхождений.'
                                    : cat.status === 'orange'
                                        ? 'Категория закреплена и находится в работе.'
                                        : 'По категории пока нет зафиксированных данных.'}
                        </div>
                    `}
                </div>
            </article>
        `;
    }).join('');
}

function renderAllReportViews(report) {
    renderEmployees(report);
    renderCategories(report);
    renderEmployeeDetails(report);
}

window.toggleAdminCategory = function (key) {
    if (adminState.expandedCategories.has(key)) {
        adminState.expandedCategories.delete(key);
    } else {
        adminState.expandedCategories.add(key);
    }
    if (adminState.report) renderCategories(adminState.report);
};

window.filterByEmployee = function (fullName) {
    adminState.employeeFilter = fullName;
    document.getElementById('admin-employee-filter').value = fullName;
    setViewMode('employees');
};

async function loadReportsList(location, sectionRequestSeq = adminState.reportsSectionRequestSeq) {
    const select = document.getElementById('admin-report-select');
    const { year, month } = getSelectedReportYearMonth();
    const monthLabel = getReportMonthLabel(month);
    select.disabled = true;
    select.innerHTML = '<option>Загрузка...</option>';
    setAdminReportLoading(`Загружаем список ревизий для точки «${location}» за ${monthLabel.toLowerCase()} ${year}...`);

    const params = new URLSearchParams({ location, year: String(year), month: String(Number(month)) });
    const response = await fetch(`/api/reports?${params.toString()}`);
    if (!response.ok) throw new Error('Ошибка загрузки списка ревизий');
    const data = await response.json();

    if (sectionRequestSeq !== adminState.reportsSectionRequestSeq) {
        return null;
    }

    if (!data.reports.length) {
        select.innerHTML = `<option value="">Нет ревизий за ${monthLabel.toLowerCase()} ${year}</option>`;
        adminState.selectedReportId = null;
        persistAdminUiState();
        updateAdminReportSelectAvailability();
        return null;
    }

    select.innerHTML = data.reports.map(report => `
        <option value="${report.report_id}" data-report-number="${report.report_number ?? ''}">${escapeHtml(report.label)}</option>
    `).join('');

    const latestReportId = Number(data.reports[0]?.report_id || 0) || null;
    if (latestReportId) {
        select.value = String(latestReportId);
    }
    adminState.selectedReportId = latestReportId;
    persistAdminUiState();
    updateAdminReportSelectAvailability();
    return latestReportId;
}

async function loadAdminReport(location, reportId) {
    const categoriesContainer = document.getElementById('report-categories');
    const employeesContainer = document.getElementById('report-employees');
    const employeeDetailsContainer = document.getElementById('report-employee-details');
    const { requestSeq, signal } = beginAdminReportViewLoad();

    const reportSelect = document.getElementById('admin-report-select');
    const selectedOption = reportSelect?.selectedOptions?.[0] || null;
    const selectedReportNumber = selectedOption && Number(selectedOption.value) === Number(reportId)
        ? (selectedOption.dataset.reportNumber || '')
        : '';

    setAdminReportLoading(reportId
        ? `Загружаем ревизию №${selectedReportNumber || reportId} для точки «${location}»...`
        : `Загружаем последнюю ревизию для точки «${location}»...`);

    try {
        const params = new URLSearchParams({ location });
        if (reportId) params.set('report_id', String(reportId));

        const response = await fetch(`/api/report?${params.toString()}`, { signal });
        let payload = null;
        try {
            payload = await response.json();
        } catch {
            payload = null;
        }
        if (!response.ok) {
            throw new Error(payload?.detail || payload?.message || 'Ошибка загрузки отчёта');
        }
        if (requestSeq !== adminState.reportViewRequestSeq) {
            return;
        }

        const report = payload;
        adminState.report = report;
        adminState.isPeriodMode = false;
        adminState.selectedReportId = report.report_id || null;
        persistAdminUiState();

        if (reportSelect && report.report_id && Array.from(reportSelect.options || []).some(option => Number(option.value) === Number(report.report_id))) {
            reportSelect.value = String(report.report_id);
        }

        updateSummary(report);
        populateEmployeeFilter(report);
        renderAllReportViews(report);
        setAdminReportStatus('');
        updateExportReportButton(report);
    } catch (error) {
        if (isAbortError(error)) {
            return;
        }

        console.error(error);
        setAdminReportStatus(error?.message || 'Не удалось загрузить данные ревизии.', 'error');
        employeesContainer.innerHTML = '<p class="empty-text error-text">Ошибка загрузки данных о сотрудниках.</p>';
        if (employeeDetailsContainer) {
            employeeDetailsContainer.innerHTML = '<div class="category-card"><p class="empty-text error-text">Ошибка загрузки детализации по сотрудникам.</p></div>';
        }
        categoriesContainer.innerHTML = '<div class="category-card"><p class="empty-text error-text">Ошибка загрузки данных ревизии.</p></div>';
        updateExportReportButton(null);
    } finally {
        finishAdminReportViewLoad(requestSeq);
    }
}

async function loadAdminPeriodReport(location, dateFrom, dateTo) {
    const categoriesContainer = document.getElementById('report-categories');
    const employeesContainer = document.getElementById('report-employees');
    const employeeDetailsContainer = document.getElementById('report-employee-details');
    const { requestSeq, signal } = beginAdminReportViewLoad();

    setAdminReportLoading(`Загружаем период ${dateFrom} — ${dateTo} для точки «${location}»...`);

    try {
        const params = new URLSearchParams({
            location,
            date_from: dateFrom,
            date_to: dateTo,
        });

        const response = await fetch(`/api/report-period?${params.toString()}`, { signal });
        let payload = null;
        try {
            payload = await response.json();
        } catch {
            payload = null;
        }
        if (!response.ok) {
            throw new Error(payload?.detail || payload?.message || 'Ошибка загрузки периода');
        }
        if (requestSeq !== adminState.reportViewRequestSeq) {
            return;
        }

        adminState.report = payload;
        adminState.isPeriodMode = true;
        adminState.periodDateFrom = dateFrom;
        adminState.periodDateTo = dateTo;

        updateSummary(payload);
        populateEmployeeFilter(payload);
        renderAllReportViews(payload);
        setAdminReportStatus('');
        updateExportReportButton(payload);
    } catch (error) {
        if (isAbortError(error)) {
            return;
        }

        console.error(error);
        setAdminReportStatus(error?.message || 'Не удалось загрузить период.', 'error');
        employeesContainer.innerHTML = '<p class="empty-text error-text">Ошибка загрузки данных о сотрудниках.</p>';
        if (employeeDetailsContainer) {
            employeeDetailsContainer.innerHTML = '<div class="category-card"><p class="empty-text error-text">Ошибка загрузки детализации по сотрудникам.</p></div>';
        }
        categoriesContainer.innerHTML = '<div class="category-card"><p class="empty-text error-text">Ошибка загрузки периода.</p></div>';
        updateExportReportButton(null);
    } finally {
        finishAdminReportViewLoad(requestSeq);
    }
}

async function resetPeriodToSelectedReport() {
    const location = getSelectedAdminLocation();
    if (!location) return;

    adminState.isPeriodMode = false;
    adminState.expandedCategories.clear();
    adminState.employeeFilter = '';

    const employeeFilterSelect = document.getElementById('admin-employee-filter');
    if (employeeFilterSelect) {
        employeeFilterSelect.value = '';
    }

    await reloadReportsSection(location);
}

async function deleteSelectedReport() {
    const locationSelect = document.getElementById('admin-location-select');
    const reportSelect = document.getElementById('admin-report-select');
    const reportId = reportSelect.value;
    if (!reportId) return;

    if (!confirm('Удалить выбранную ревизию?')) return;
    const response = await fetch(`/api/report/${reportId}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok) {
        alert(data.detail || data.message || 'Не удалось удалить ревизию.');
        return;
    }
    await reloadReportsSection(locationSelect.value);
}

async function reloadReportsSection(location) {
    const sectionRequestSeq = ++adminState.reportsSectionRequestSeq;
    if (adminState.reportViewAbortController) {
        adminState.reportViewAbortController.abort();
    }

    adminState.selectedLocation = location;
    adminState.selectedReportId = null;
    persistAdminUiState();
    adminState.employeeFilter = '';
    adminState.expandedCategories.clear();

    const employeeFilterSelect = document.getElementById('admin-employee-filter');
    if (employeeFilterSelect) {
        employeeFilterSelect.value = '';
    }

    const reportSelect = document.getElementById('admin-report-select');
    if (!location) {
        if (reportSelect) {
            reportSelect.innerHTML = '<option value="">Нет точек</option>';
            reportSelect.disabled = true;
            reportSelect.onchange = null;
        }
        return;
    }

    if (reportSelect) {
        reportSelect.onchange = null;
    }

    const reportId = await loadReportsList(location, sectionRequestSeq);
    if (sectionRequestSeq !== adminState.reportsSectionRequestSeq) {
        return;
    }
    if (!reportId) {
        setAdminReportStatus('Для этой точки пока нет сохранённых ревизий.', 'error');
        return;
    }

    await loadAdminReport(location, reportId);
    if (sectionRequestSeq !== adminState.reportsSectionRequestSeq || !reportSelect) {
        return;
    }

    reportSelect.onchange = async () => {
        if (adminState.isReportViewLoading) {
            return;
        }

        const currentLocation = getSelectedAdminLocation();
        const selected = reportSelect.value ? Number(reportSelect.value) : null;
        adminState.selectedReportId = selected;
        persistAdminUiState();
        adminState.expandedCategories.clear();
        await loadAdminReport(currentLocation, selected);
    };
}

async function deleteSelectedEmployeeReport() {
    // заглушка, если вдруг понадобится отдельная логика потом
}

function openDiscrepancyEditModal(item) {
    adminState.editingDiscrepancy = item;

    const itemName = document.getElementById('edit-discrepancy-item-name');
    const itemMeta = document.getElementById('edit-discrepancy-item-meta');
    const actualInput = document.getElementById('edit-discrepancy-actual');
    const passwordInput = document.getElementById('edit-discrepancy-password');
    const message = document.getElementById('edit-discrepancy-message');

    if (itemName) itemName.textContent = item.name || 'Товар';
    if (itemMeta) {
        itemMeta.textContent = `План: ${formatEditableQty(item.expected)} · Текущий факт: ${formatEditableQty(item.actual)} · ${item.category_name || 'Без категории'}${item.subcategory_name ? ` → ${item.subcategory_name}` : ''}`;
    }
    if (actualInput) actualInput.value = formatEditableQty(item.actual);
    if (passwordInput) passwordInput.value = '';
    if (message) {
        message.textContent = '';
        message.className = 'message';
    }

    showModal('edit-discrepancy-modal');
    setTimeout(() => actualInput?.focus(), 0);
}

function closeDiscrepancyEditModal() {
    adminState.editingDiscrepancy = null;
    hideModal('edit-discrepancy-modal');

    const form = document.getElementById('edit-discrepancy-form');
    const message = document.getElementById('edit-discrepancy-message');
    if (form) form.reset();
    if (message) {
        message.textContent = '';
        message.className = 'message';
    }
}

async function submitDiscrepancyEditForm(event) {
    event.preventDefault();
    const item = adminState.editingDiscrepancy;
    if (!item?.check_result_id) return;

    const actualInput = document.getElementById('edit-discrepancy-actual');
    const passwordInput = document.getElementById('edit-discrepancy-password');
    const submitButton = document.getElementById('save-discrepancy-edit-btn');
    const message = document.getElementById('edit-discrepancy-message');

    const actualQuantity = Number(actualInput?.value);
    const password = String(passwordInput?.value || '');

    if (!Number.isFinite(actualQuantity) || actualQuantity < 0) {
        if (message) {
            message.textContent = 'Введите корректный факт (0 или больше).';
            message.className = 'message';
        }
        actualInput?.focus();
        return;
    }

    if (!password.trim()) {
        if (message) {
            message.textContent = 'Введите пароль текущего управляющего.';
            message.className = 'message';
        }
        passwordInput?.focus();
        return;
    }

    if (submitButton) submitButton.disabled = true;
    if (message) {
        message.textContent = 'Сохраняем изменения...';
        message.className = 'message';
    }

    try {
        const response = await fetch(`/api/report/discrepancy/${item.check_result_id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                actual_quantity: actualQuantity,
                password,
            }),
        });

        let payload = null;
        try {
            payload = await response.json();
        } catch {
            payload = null;
        }

        if (!response.ok) {
            throw new Error(payload?.detail || payload?.message || 'Не удалось обновить расхождение.');
        }

        const location = getSelectedAdminLocation();
        const currentReportId = getCurrentAdminReportId();
        await loadAdminReport(location, currentReportId);
        closeDiscrepancyEditModal();
        setAdminReportStatus(payload?.message || 'Расхождение обновлено.', 'success');
    } catch (error) {
        if (message) {
            message.textContent = error?.message || 'Не удалось обновить расхождение.';
            message.className = 'message';
        }
    } finally {
        if (submitButton) submitButton.disabled = false;
    }
}

function openCostOverrideModal(item) {
    adminState.editingCostOverride = item;

    const itemName = document.getElementById('edit-cost-override-item-name');
    const itemMeta = document.getElementById('edit-cost-override-item-meta');
    const costInput = document.getElementById('edit-cost-override-value');
    const noteInput = document.getElementById('edit-cost-override-note');
    const message = document.getElementById('edit-cost-override-message');

    if (itemName) itemName.textContent = item.name || 'Товар';
    if (itemMeta) {
        const sourceLabel = item.cost_price_source === 'override' ? 'Локальная себестоимость уже задана для этой точки.' : 'Сейчас используется общий кеш точки.';
        itemMeta.textContent = `${item.category_name || 'Без категории'}${item.subcategory_name ? ` → ${item.subcategory_name}` : ''} · ${sourceLabel}`;
    }
    if (costInput) costInput.value = item.cost_price != null && Number.isFinite(Number(item.cost_price)) ? String(Number(item.cost_price)) : '';
    if (noteInput) noteInput.value = item.cost_price_note || '';
    if (message) {
        message.textContent = '';
        message.className = 'message';
    }

    showModal('edit-cost-override-modal');
    setTimeout(() => costInput?.focus(), 0);
}

function closeCostOverrideModal() {
    adminState.editingCostOverride = null;
    hideModal('edit-cost-override-modal');

    const form = document.getElementById('edit-cost-override-form');
    const message = document.getElementById('edit-cost-override-message');
    if (form) form.reset();
    if (message) {
        message.textContent = '';
        message.className = 'message';
    }
}

async function submitCostOverrideForm(event) {
    event.preventDefault();
    const item = adminState.editingCostOverride;
    if (!item?.check_result_id) return;

    const costInput = document.getElementById('edit-cost-override-value');
    const noteInput = document.getElementById('edit-cost-override-note');
    const submitButton = document.getElementById('save-cost-override-btn');
    const clearButton = document.getElementById('clear-cost-override-btn');
    const message = document.getElementById('edit-cost-override-message');

    const rawCost = String(costInput?.value || '').trim().replace(',', '.');
    const note = String(noteInput?.value || '').trim();
    let costPrice = null;
    if (rawCost !== '') {
        costPrice = Number(rawCost);
        if (!Number.isFinite(costPrice) || costPrice < 0) {
            if (message) {
                message.textContent = 'Введите корректную себестоимость или очистите поле, чтобы удалить локальное значение.';
                message.className = 'message';
            }
            costInput?.focus();
            return;
        }
    }

    if (submitButton) submitButton.disabled = true;
    if (clearButton) clearButton.disabled = true;
    if (message) {
        message.textContent = costPrice === null ? 'Удаляем локальную себестоимость...' : 'Сохраняем локальную себестоимость...';
        message.className = 'message';
    }

    try {
        const response = await fetch(`/api/report/discrepancy-cost/${item.check_result_id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                cost_price: costPrice,
                note: note || null,
            }),
        });

        let payload = null;
        try {
            payload = await response.json();
        } catch {
            payload = null;
        }

        if (!response.ok) {
            throw new Error(payload?.detail || payload?.message || 'Не удалось сохранить локальную себестоимость.');
        }

        const location = getSelectedAdminLocation();
        if (adminState.isPeriodMode && adminState.periodDateFrom && adminState.periodDateTo) {
            await loadAdminPeriodReport(location, adminState.periodDateFrom, adminState.periodDateTo);
        } else {
            const currentReportId = getCurrentAdminReportId();
            await loadAdminReport(location, currentReportId);
        }
        closeCostOverrideModal();
        setAdminReportStatus(payload?.message || 'Локальная себестоимость сохранена.', 'success');
    } catch (error) {
        if (message) {
            message.textContent = error?.message || 'Не удалось сохранить локальную себестоимость.';
            message.className = 'message';
        }
    } finally {
        if (submitButton) submitButton.disabled = false;
        if (clearButton) clearButton.disabled = false;
    }
}


async function logout() {
    await fetch('/api/logout', { method: 'POST' });
    location.href = '/login';
}

function initModalCloseBehavior() {
    document.querySelectorAll('.modal-overlay').forEach((overlay) => {
        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) {
                overlay.classList.add('hidden');
                if (document.querySelectorAll('.modal-overlay:not(.hidden)').length === 0) {
                    document.body.classList.remove('modal-open');
                }
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    const locationSelect = document.getElementById('admin-location-select');
    const employeeFilter = document.getElementById('admin-employee-filter');
    const discrepancyOnly = document.getElementById('admin-discrepancy-only');
    const searchInput = document.getElementById('admin-search-input');
    const userRoleSelect = document.getElementById('user-role');

    document.getElementById('logout-btn').addEventListener('click', logout);
    document.getElementById('open-users-btn').addEventListener('click', async () => {
        showModal('users-modal');
        await loadUsers();
    });
    document.getElementById('open-create-location-btn')?.addEventListener('click', () => openLocationModal('create'));
    document.getElementById('open-cycle-targets-btn')?.addEventListener('click', async () => {
        try {
            await openCycleTargetsModal(getTodayIsoDate());
        } catch (error) {
            console.error(error);
            alert('Не удалось загрузить категории цикла.');
        }
    });
    document.getElementById('close-location-modal-btn')?.addEventListener('click', () => hideModal('location-modal'));
    document.getElementById('load-stores-btn')?.addEventListener('click', loadStoresByToken);
    document.getElementById('load-edit-stores-btn')?.addEventListener('click', loadEditStoresByToken);
    document.getElementById('location-form')?.addEventListener('submit', submitLocationForm);
    document.getElementById('location-edit-form')?.addEventListener('submit', submitLocationEditForm);
    document.getElementById('delete-location-btn')?.addEventListener('click', deleteSelectedLocation);
    document.querySelectorAll('[data-location-tab]').forEach(button => {
        button.addEventListener('click', () => switchLocationModalTab(button.dataset.locationTab || 'create'));
    });
    document.getElementById('location-manage-list')?.addEventListener('click', (event) => {
        const button = event.target.closest('[data-location-edit-id]');
        if (!button) return;
        selectLocationForEdit(Number(button.dataset.locationEditId));
    });
    document.getElementById('close-cycle-targets-modal-btn')?.addEventListener('click', () => hideModal('cycle-targets-modal'));
    document.getElementById('save-cycle-targets-btn')?.addEventListener('click', saveCycleTargetsSelection);
    document.getElementById('apply-previous-cycle-targets-btn')?.addEventListener('click', applyPreviousCycleTargetsSelection);
    document.getElementById('cycle-target-date')?.addEventListener('change', async (event) => {
        const nextDate = event.target?.value || '';
        if (!nextDate) return;
        try {
            await openCycleTargetsModal(nextDate);
        } catch (error) {
            console.error(error);
            alert('Не удалось загрузить подкатегории на выбранную дату.');
        }
    });
    document.getElementById('close-users-modal-btn').addEventListener('click', () => hideModal('users-modal'));
    document.getElementById('open-create-user-btn').textContent = isSuperadmin() ? 'Добавить пользователя' : 'Добавить сотрудника';
    document.getElementById('open-create-user-btn').addEventListener('click', openCreateUserModal);
    document.getElementById('close-user-form-modal-btn').addEventListener('click', () => {
        hideModal('user-form-modal');
        resetUserForm();
    });
    document.getElementById('user-form').addEventListener('submit', submitUserForm);
    userRoleSelect?.addEventListener('change', () => updateUserFormByRole());
    document.getElementById('user-form-reset').addEventListener('click', resetUserForm);
    document.getElementById('delete-report-btn').addEventListener('click', deleteSelectedReport);
    document.getElementById('export-report-xlsx-btn')?.addEventListener('click', async () => {
        await downloadCurrentReportExcel(document.getElementById('export-report-xlsx-btn'));
    });
    syncProblemExportDates(true);
    document.getElementById('problem-export-preset')?.addEventListener('change', () => syncProblemExportDates(true));
    document.getElementById('problem-export-date-from')?.addEventListener('change', () => {
        const preset = document.getElementById('problem-export-preset');
        if (preset) preset.value = 'custom';
        syncProblemExportDates(false);
    });
    document.getElementById('problem-export-date-to')?.addEventListener('change', () => {
        const preset = document.getElementById('problem-export-preset');
        if (preset) preset.value = 'custom';
        syncProblemExportDates(false);
    });
    document.getElementById('export-problem-items-xlsx-btn')?.addEventListener('click', async () => {
        await downloadProblemItemsChecklistExcel(document.getElementById('export-problem-items-xlsx-btn'));
    });
    document.getElementById('load-period-report-btn')?.addEventListener('click', async () => {
        const fromInput = document.getElementById('admin-period-date-from');
        const toInput = document.getElementById('admin-period-date-to');
        const dateFrom = fromInput?.value || '';
        const dateTo = toInput?.value || '';
        if (!dateFrom || !dateTo) {
            alert('Выберите обе даты периода.');
            return;
        }
        if (dateFrom > dateTo) {
            alert('Дата начала периода не может быть позже даты окончания.');
            return;
        }
        const location = locationSelect.value;
        if (!location) return;
        adminState.employeeFilter = '';
        adminState.expandedCategories.clear();
        await loadAdminPeriodReport(location, dateFrom, dateTo);
    });
    document.getElementById('reset-period-report-btn')?.addEventListener('click', resetPeriodToSelectedReport);
    document.getElementById('download-diagnostics-btn')?.addEventListener('click', async () => {
        const location = locationSelect.value;
        if (!location) return;
        await openDiagnosticsModal(location, document.getElementById('download-diagnostics-btn'));
    });
    document.getElementById('close-diagnostics-modal-btn')?.addEventListener('click', () => hideModal('diagnostics-modal'));
    document.getElementById('diagnostics-export-btn')?.addEventListener('click', async () => {
        const location = adminState.diagnosticsLocation || locationSelect.value;
        if (!location) return;
        await downloadDiagnosticsCsv(location, document.getElementById('diagnostics-export-btn'));
    });
    document.getElementById('close-edit-discrepancy-modal-btn')?.addEventListener('click', closeDiscrepancyEditModal);
    document.getElementById('edit-discrepancy-cancel-btn')?.addEventListener('click', closeDiscrepancyEditModal);
    document.getElementById('edit-discrepancy-form')?.addEventListener('submit', submitDiscrepancyEditForm);
    document.getElementById('close-edit-cost-override-modal-btn')?.addEventListener('click', closeCostOverrideModal);
    document.getElementById('edit-cost-override-cancel-btn')?.addEventListener('click', closeCostOverrideModal);
    document.getElementById('clear-cost-override-btn')?.addEventListener('click', async () => {
        const input = document.getElementById('edit-cost-override-value');
        const note = document.getElementById('edit-cost-override-note');
        if (input) input.value = '';
        if (note) note.value = '';
        const form = document.getElementById('edit-cost-override-form');
        if (form) await submitCostOverrideForm(new Event('submit', { cancelable: true }));
    });
    document.getElementById('edit-cost-override-form')?.addEventListener('submit', submitCostOverrideForm);

    document.querySelectorAll('[data-view-mode]').forEach(button => {
        button.addEventListener('click', () => setViewMode(button.dataset.viewMode));
    });

    document.addEventListener('click', async (event) => {
        const editDiscrepancyButton = event.target.closest('[data-edit-discrepancy]');
        if (editDiscrepancyButton) {
            openDiscrepancyEditModal({
                check_result_id: Number(editDiscrepancyButton.dataset.checkResultId),
                category_name: editDiscrepancyButton.dataset.categoryName || '',
                subcategory_name: editDiscrepancyButton.dataset.subcategoryName || '',
                name: editDiscrepancyButton.dataset.itemName || '',
                expected: Number(editDiscrepancyButton.dataset.expected || 0),
                actual: Number(editDiscrepancyButton.dataset.actual || 0),
            });
            return;
        }

        const editCostOverrideButton = event.target.closest('[data-edit-cost-override]');
        if (editCostOverrideButton) {
            openCostOverrideModal({
                check_result_id: Number(editCostOverrideButton.dataset.checkResultId),
                category_name: editCostOverrideButton.dataset.categoryName || '',
                subcategory_name: editCostOverrideButton.dataset.subcategoryName || '',
                name: editCostOverrideButton.dataset.itemName || '',
                cost_price: editCostOverrideButton.dataset.costPrice === '' ? null : Number(editCostOverrideButton.dataset.costPrice),
                cost_price_note: editCostOverrideButton.dataset.costNote || '',
                cost_price_source: editCostOverrideButton.dataset.costSource || '',
            });
            return;
        }

        const actionButton = event.target.closest('[data-open-modal-action]');
        if (!actionButton) return;

        if (actionButton.dataset.openModalAction === 'location') {
            openLocationModal('create');
            return;
        }

        if (actionButton.dataset.openModalAction === 'cycle-targets') {
            try {
                await openCycleTargetsModal();
            } catch (error) {
                console.error(error);
                alert('Не удалось загрузить категории цикла.');
            }
        }
    });

    document.getElementById('admin-report-year-select')?.addEventListener('change', async (event) => {
        adminState.selectedReportYear = Number(event.target.value) || getDefaultReportYearMonth().year;
        adminState.selectedReportId = null;
        persistAdminUiState();
        const location = adminState.selectedLocation || locationSelect.value;
        if (location) await reloadReportsSection(location);
    });

    document.getElementById('admin-report-month-select')?.addEventListener('change', async (event) => {
        adminState.selectedReportMonth = normalizeReportMonth(event.target.value) || getDefaultReportYearMonth().month;
        adminState.selectedReportId = null;
        persistAdminUiState();
        const location = adminState.selectedLocation || locationSelect.value;
        if (location) await reloadReportsSection(location);
    });

    locationSelect.addEventListener('change', async () => {
        const nextLocation = locationSelect.value;
        adminState.selectedLocation = nextLocation;
        adminState.selectedReportId = null;
        setProblemExportStatus('');
        syncProblemExportDates(true);
        persistAdminUiState();
        await reloadReportsSection(nextLocation);
    });

    employeeFilter.addEventListener('change', () => {
        adminState.employeeFilter = employeeFilter.value;
        if (adminState.report) {
            renderAllReportViews(adminState.report);
        }
    });

    discrepancyOnly.addEventListener('change', () => {
        adminState.discrepancyOnly = discrepancyOnly.checked;
        if (adminState.report) {
            renderAllReportViews(adminState.report);
        }
    });

    searchInput?.addEventListener('input', () => {
        adminState.searchQuery = searchInput.value.trim();
        if (adminState.report) {
            renderAllReportViews(adminState.report);
        }
    });

    initModalCloseBehavior();
    setViewMode('categories');
    updateUserFormByRole();
    applyDefaultPeriodInputs();
    renderReportMonthSelectors();
    await loadLocations();
    await reloadReportsSection(adminState.selectedLocation || document.getElementById('admin-location-select').value);
});